import crypto from "node:crypto";
import { assessCareer } from "./careerEngine";
import { adminClient, ensureUser, getAuthUser } from "./server-auth";
import type { NextRequest } from "next/server";

export type JourneyAction =
  | "ACCEPT" | "REFUSE" | "DEFER" | "COMPLETE" | "ABANDON" | "REASSESS";

function cleanString(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

function clamp(n: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Math.round(n)));
}

async function loadContext(supabase: any, userId: string) {
  const [profile, experiences, skills, education, applications] = await Promise.all([
    supabase.from("Profile").select("*").eq("userId", userId).maybeSingle(),
    supabase.from("Experience").select("*").eq("userId", userId).order("startDate", { ascending: false }),
    supabase.from("Skill").select("*").eq("userId", userId).order("name"),
    supabase.from("Education").select("*").eq("userId", userId).order("startDate", { ascending: false }),
    supabase.from("Application").select("id,status,createdAt,updatedAt").eq("userId", userId).order("updatedAt", { ascending: false }).limit(100),
  ]);
  for (const r of [profile, experiences, skills, education, applications]) if (r.error) throw new Error(r.error.message);
  return {
    profile: profile.data,
    experiences: experiences.data ?? [],
    skills: skills.data ?? [],
    education: education.data ?? [],
    applications: applications.data ?? [],
  };
}

export async function getOrCreateJourney(request: NextRequest) {
  const authUser = await getAuthUser(request);
  if (!authUser) throw Object.assign(new Error("Session requise."), { status: 401 });
  const supabase = adminClient();
  const user = await ensureUser(supabase, authUser);
  let { data: journey, error } = await supabase.from("CareerJourney").select("*").eq("userId", user.id).maybeSingle();
  if (error) throw new Error(error.message);

  const context = await loadContext(supabase, user.id);
  if (!journey) {
    const assessment = assessCareer({
      experiences: context.experiences,
      skills: context.skills,
      education: context.education,
      targetRole: context.profile?.targetRoles?.[0] ?? null,
    });
    const snapshot = {
      readiness: assessment.readiness,
      currentLevel: assessment.currentLevel,
      targetLevel: assessment.targetLevel,
      dimensions: assessment.dimensions,
      gaps: assessment.gaps,
      nextBestAction: assessment.nextBestAction,
      missingData: [
        ...(context.experiences.length ? [] : ["expériences"]),
        ...(context.skills.length ? [] : ["compétences"]),
        ...(context.education.length ? [] : ["formation"]),
        ...(context.profile?.targetRoles?.length ? [] : ["objectif professionnel"]),
      ],
    };
    const inserted = await supabase.from("CareerJourney").insert({
      id: crypto.randomUUID(),
      userId: user.id,
      targetRole: context.profile?.targetRoles?.[0] ?? null,
      baselineReadiness: assessment.readiness,
      latestReadiness: assessment.readiness,
      baselineSnapshot: snapshot,
      latestSnapshot: snapshot,
    }).select("*").single();
    if (inserted.error) throw new Error(inserted.error.message);
    journey = inserted.data;
  }

  const [goals, missions, recommendations, scenarios, reviews] = await Promise.all([
    supabase.from("CareerGoal").select("*").eq("journeyId", journey.id).order("priority"),
    supabase.from("CareerMission").select("*").eq("journeyId", journey.id).order("createdAt", { ascending: false }),
    supabase.from("CareerRecommendation").select("*").eq("journeyId", journey.id).order("createdAt", { ascending: false }).limit(10),
    supabase.from("CareerPathScenario").select("*").eq("journeyId", journey.id).order("createdAt", { ascending: false }),
    supabase.from("CareerReview").select("*").eq("journeyId", journey.id).order("periodEnd", { ascending: false }).limit(5),
  ]);
  for (const r of [goals, missions, recommendations, scenarios, reviews]) if (r.error) throw new Error(r.error.message);

  return { supabase, user, context, journey, goals: goals.data ?? [], missions: missions.data ?? [], recommendations: recommendations.data ?? [], scenarios: scenarios.data ?? [], reviews: reviews.data ?? [] };
}

export async function createRecommendation(supabase: any, userId: string, journeyId: string, input: {
  type: string; title: string; rationale: string; gap?: string | null; expectedOutcome?: string | null; goalId?: string | null; alternatives?: unknown; assumptions?: unknown; missingData?: unknown;
}) {
  const allowed = new Set(["APPLY","DEFER_APPLICATION","UPDATE_CV","LEARN","PRACTICE","PROJECT","PORTFOLIO","INTERVIEW_PREP","EXPLORE_PATH","REASSESS","READY_TO_APPLY"]);
  if (!allowed.has(input.type)) throw new Error("Type de recommandation invalide.");
  const row = {
    id: crypto.randomUUID(), userId, journeyId, goalId: input.goalId ?? null,
    type: input.type, title: input.title.trim(), rationale: input.rationale.trim(),
    gap: input.gap ?? null, expectedOutcome: input.expectedOutcome ?? null,
    alternatives: input.alternatives ?? [], assumptions: input.assumptions ?? [], missingData: input.missingData ?? [],
  };
  const { data, error } = await supabase.from("CareerRecommendation").insert(row).select("*").single();
  if (error) throw new Error(error.message);
  return data;
}

export async function generateJourneyRecommendations(ctx: Awaited<ReturnType<typeof getOrCreateJourney>>) {
  const { supabase, user, context, journey } = ctx;
  const assessment = assessCareer({
    experiences: context.experiences,
    skills: context.skills,
    education: context.education,
    targetRole: journey.targetRole ?? context.profile?.targetRoles?.[0] ?? null,
  });
  const missingData = [
    ...(context.experiences.length ? [] : ["expériences"]),
    ...(context.skills.length ? [] : ["compétences"]),
    ...(context.education.length ? [] : ["formation"]),
    ...(journey.targetRole ? [] : ["objectif professionnel"]),
  ];
  const created = [];
  const primaryGap = assessment.gaps[0] ?? null;
  const learningGap = assessment.gaps.find((gap) => /formation|certification|compétence/i.test(gap)) ?? null;

  if (learningGap) {
    created.push(await createRecommendation(supabase, user.id, journey.id, {
      type: "LEARN",
      title: /formation/i.test(learningGap)
        ? "Choisir une formation pertinente pour réduire l'écart"
        : "Renforcer la compétence clé avec une formation ciblée",
      rationale: `J’IA identifie un besoin d’apprentissage structuré : ${learningGap}. La formation est proposée comme option lorsque l’acquisition de la compétence nécessite un apprentissage formel ; elle reste soumise à votre validation.`,
      gap: learningGap,
      expectedOutcome: "Acquérir ou consolider la compétence ciblée puis produire une preuve exploitable lors de la prochaine réévaluation.",
      missingData,
      assumptions: [
        "La formation est une option, pas une obligation.",
        "Le choix final de la formation appartient à l'utilisateur.",
        "Aucun organisme, prix, certification ou résultat n'est affirmé sans source de formation vérifiée."
      ],
      alternatives: [
        { type: "FORMATION", label: "Formation courte ciblée", topic: learningGap },
        { type: "RESOURCE", label: "Ressource d'apprentissage autonome", topic: learningGap },
        { type: "PRACTICE", label: "Projet ou mise en pratique guidée", topic: learningGap }
      ],
    }));
  } else if (primaryGap) {
    created.push(await createRecommendation(supabase, user.id, journey.id, {
      type: assessment.readiness >= 70 ? "APPLY" : "PRACTICE",
      title: assessment.readiness >= 70 ? "Postuler sur les offres suffisamment alignées" : "Réduire l'écart prioritaire",
      rationale: assessment.nextBestAction,
      gap: primaryGap,
      expectedOutcome: "Obtenir un nouvel élément exploitable pour la prochaine réévaluation.",
      missingData,
      assumptions: ["Analyse fondée uniquement sur les informations actuellement disponibles."],
      alternatives: ["Mettre à jour le profil", "Explorer une autre trajectoire", "Postuler malgré l'incertitude"],
    }));
  } else {
    created.push(await createRecommendation(supabase, user.id, journey.id, {
      type: "READY_TO_APPLY",
      title: "Prêt à explorer des candidatures",
      rationale: "Les informations disponibles ne font pas apparaître d'écart critique dans l'analyse actuelle.",
      expectedOutcome: "Passer à la préparation de candidature ou d'entretien.",
      missingData,
      alternatives: ["Adapter le CV", "Préparer un entretien", "Explorer un autre objectif"],
    }));
  }
  const { data: persistedJourney, error: journeyUpdateError } = await supabase
    .from("CareerJourney")
    .update({
      latestReadiness: assessment.readiness,
      latestSnapshot: { readiness: assessment.readiness, currentLevel: assessment.currentLevel, targetLevel: assessment.targetLevel, dimensions: assessment.dimensions, gaps: assessment.gaps, nextBestAction: assessment.nextBestAction, missingData },
      lastReevaluatedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    })
    .eq("id", journey.id)
    .eq("userId", user.id)
    .select("id,latestReadiness,lastReevaluatedAt")
    .maybeSingle();
  if (journeyUpdateError) throw new Error(`Impossible de persister la réévaluation Career Journey : ${journeyUpdateError.message}`);
  if (!persistedJourney) throw new Error("La réévaluation Career Journey n'a modifié aucun parcours.");
  return { assessment, created, persistedJourney };
}

export async function updateMission(supabase: any, userId: string, missionId: string, action: JourneyAction, patch: any = {}) {
  const { data: mission, error } = await supabase.from("CareerMission").select("*").eq("id", missionId).eq("userId", userId).maybeSingle();
  if (error) throw new Error(error.message);
  if (!mission) throw Object.assign(new Error("Mission introuvable."), { status: 404 });

  const now = new Date().toISOString();
  const statusByAction: Record<JourneyAction, string | undefined> = {
    ACCEPT: "ACCEPTED", REFUSE: "ABANDONED", DEFER: "DEFERRED", COMPLETE: "COMPLETED", ABANDON: "ABANDONED", REASSESS: undefined,
  };
  const status = statusByAction[action];
  const transitions: Record<JourneyAction, string[]> = {
    ACCEPT: ["PROPOSED", "DEFERRED"],
    REFUSE: ["PROPOSED", "DEFERRED"],
    DEFER: ["PROPOSED", "ACCEPTED", "IN_PROGRESS"],
    COMPLETE: ["IN_PROGRESS", "ACCEPTED"],
    ABANDON: ["ACCEPTED", "IN_PROGRESS", "DEFERRED"],
    REASSESS: [],
  };
  if (action === "REASSESS") throw Object.assign(new Error("La réévaluation est une action de parcours, pas une transition de mission."), { status: 400 });
  if (!transitions[action].includes(mission.status)) {
    throw Object.assign(new Error("Transition de mission invalide : " + mission.status + " → " + (status ?? action) + "."), { status: 409 });
  }
  const progress = patch.progress == null ? mission.progressPercent : clamp(Number(patch.progress));
  const data: any = { progressPercent: progress, updatedAt: now };
  if (status) data.status = status;
  if (action === "ACCEPT") data.acceptedAt = now;
  if (action === "DEFER") data.deferredAt = now;
  if (action === "COMPLETE") { data.completedAt = now; data.progressPercent = 100; }
  if (action === "ABANDON" || action === "REFUSE") data.abandonedAt = now;
  if (patch.dueAt !== undefined) data.dueAt = patch.dueAt || null;
  if (patch.followUpAt !== undefined) data.followUpAt = patch.followUpAt || null;
  const updated = await supabase.from("CareerMission")
    .update(data)
    .eq("id", missionId)
    .eq("userId", userId)
    .eq("status", mission.status)
    .select("*")
    .maybeSingle();
  if (updated.error) throw new Error(updated.error.message);
  if (!updated.data) throw Object.assign(new Error("La mission a changé depuis son chargement. Rechargez le parcours avant de réessayer."), { status: 409 });

  const { data: missionUpdate, error: missionUpdateError } = await supabase.from("CareerMissionUpdate").insert({
    id: crypto.randomUUID(), missionId, status: status ?? null, progress: data.progressPercent,
    note: cleanString(patch.note), response: patch.response ?? null,
  }).select("id").single();
  if (missionUpdateError || !missionUpdate) {
    const rollback = await supabase.from("CareerMission").update({
      status: mission.status,
      progressPercent: mission.progressPercent,
      acceptedAt: mission.acceptedAt,
      deferredAt: mission.deferredAt,
      completedAt: mission.completedAt,
      abandonedAt: mission.abandonedAt,
      dueAt: mission.dueAt,
      followUpAt: mission.followUpAt,
      updatedAt: mission.updatedAt,
    }).eq("id", missionId).eq("userId", userId).eq("updatedAt", now).select("id").maybeSingle();
    const journalReason = missionUpdateError?.message ?? "aucune ligne retournée";
    if (rollback.error || !rollback.data) {
      throw new Error(`Journal de progression non persisté (${journalReason}) et retour arrière non confirmé (${rollback.error?.message ?? "ligne déjà modifiée ou introuvable"}).`);
    }
    throw new Error(`Journal de progression non persisté ; transition annulée (${journalReason}).`);
  }
  return updated.data;
}

export async function validateMissionOwnership(supabase: any, userId: string, missionId: string) {
  const { data, error } = await supabase.from("CareerMission").select("id,journeyId,goalId,status").eq("id", missionId).eq("userId", userId).maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw Object.assign(new Error("Mission introuvable."), { status: 404 });
  return data;
}

export function sanitizeAssessmentAnswers(input: unknown) {
  if (!input || typeof input !== "object") return {};
  const record = input as Record<string, unknown>;
  return Object.fromEntries(Object.entries(record).slice(0, 50).map(([key, value]) => {
    if (Array.isArray(value)) return [key, value.slice(0, 4)];
    if (typeof value === "string") return [key, value.slice(0, 4000)];
    if (typeof value === "number" || typeof value === "boolean") return [key, value];
    return [key, null];
  }));
}


export type PerformanceMetricUnit = "PERCENT" | "COUNT" | "CURRENCY" | "TIME" | "RATE" | "TEXT";
export type CareerEvidenceKind = "PHOTO" | "DOCUMENT" | "RESULT" | "CASE" | "CHALLENGE" | "TESTIMONIAL" | "LINK" | "NOTE";

export type PerformanceMissionSpec = {
  title: string;
  roleContext?: string | null;
  periodStart?: string | null;
  periodEnd?: string | null;
  metric: string;
  unit: PerformanceMetricUnit;
  baseline?: number | null;
  target?: number | null;
  actual?: number | null;
  source?: "USER_DECLARED" | "DOCUMENT" | "INTEGRATION" | "EMPLOYER" | "OTHER" | null;
  challenge?: string | null;
};

export type CareerEvidenceSpec = {
  kind: CareerEvidenceKind;
  title: string;
  description?: string | null;
  occurredAt?: string | null;
  source?: string | null;
  metric?: string | null;
  value?: number | null;
  unit?: PerformanceMetricUnit | null;
  verified?: boolean;
};

/**
 * Turns a real-world result into a measurable, user-validated career signal.
 * Never invents a KPI: baseline/target/actual are optional until supplied or verified.
 */
export function buildPerformanceMission(spec: PerformanceMissionSpec) {
  const baseline = typeof spec.baseline === "number" ? spec.baseline : null;
  const target = typeof spec.target === "number" ? spec.target : null;
  const actual = typeof spec.actual === "number" ? spec.actual : null;
  const progress = baseline != null && target != null && target !== baseline && actual != null
    ? clamp(((actual - baseline) / (target - baseline)) * 100)
    : null;

  return {
    type: "PERFORMANCE" as const,
    title: spec.title.trim(),
    roleContext: cleanString(spec.roleContext),
    periodStart: cleanString(spec.periodStart),
    periodEnd: cleanString(spec.periodEnd),
    metric: spec.metric.trim(),
    unit: spec.unit,
    baseline,
    target,
    actual,
    progress,
    source: spec.source ?? null,
    challenge: cleanString(spec.challenge),
    evidenceRequired: true,
  };
}

/**
 * Builds a compact evidence trail that can later feed a CV bullet, portfolio case
 * or reassessment. Evidence remains attributable and must be validated by the user.
 */
export function buildCareerEvidence(spec: CareerEvidenceSpec) {
  return {
    kind: spec.kind,
    title: spec.title.trim(),
    description: cleanString(spec.description),
    occurredAt: cleanString(spec.occurredAt),
    source: cleanString(spec.source),
    metric: cleanString(spec.metric),
    value: typeof spec.value === "number" ? spec.value : null,
    unit: spec.unit ?? null,
    verified: spec.verified === true,
  };
}

/**
 * Produces CV-ready raw material only. It does not claim a result that is absent
 * from the evidence and never edits the user's CV automatically.
 */
export function quantifyCareerEvidence(input: {
  action: string;
  context?: string | null;
  evidence: Array<CareerEvidenceSpec>;
}) {
  const verified = input.evidence.filter((item) => item.verified === true);
  const measurable = verified.filter((item) => typeof item.value === "number" && item.metric);
  return {
    action: input.action.trim(),
    context: cleanString(input.context),
    verifiedEvidenceCount: verified.length,
    measurableEvidence: measurable.map((item) => ({
      metric: item.metric!.trim(),
      value: item.value,
      unit: item.unit ?? null,
      source: cleanString(item.source),
    })),
    cvDraftEligible: measurable.length > 0,
    requiresUserApproval: true,
  };
}
