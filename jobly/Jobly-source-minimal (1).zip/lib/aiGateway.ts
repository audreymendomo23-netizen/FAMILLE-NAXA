import { JIA_NAME } from "./ai/brand";
import crypto from "node:crypto";
import { NextRequest } from "next/server";
import { adminClient, ensureUser, getAuthUser } from "./server-auth";
import { AI_CREDITS_BY_PLAN, AI_OPERATION_COST, type AiOperation, type AiPlan } from "./aiEconomics";
import { buildJiaContext } from "./jiaContext";
import { maybeCreateJiaUpgradeNudge } from "./jia/subscriptionNudge";

export type GatewayResult = { ok:true; operation:AiOperation; credits:number; remaining:number; provider:string; aiName:typeof JIA_NAME; output:unknown } | { ok:false; status:number; message:string; upgradeSuggestion?: Awaited<ReturnType<typeof maybeCreateJiaUpgradeNudge>> };
const OPS = new Set<AiOperation>(["OFFER_INTELLIGENCE","CV_INTELLIGENCE","MATCHING","APPLICATION_COPILOT","APPLICATION_STRATEGY","LEARNING","INTERVIEW","CAREER_COMPANION","NOTIFICATION"]);
const normalize=(v:string)=>{const x=v.toUpperCase() as AiOperation; return OPS.has(x)?x:null};
const planOf=(s:any):AiPlan=>{const p=String(s?.planCode||s?.plan||"FREE"); return (["FREE","START","PREMIUM","PRO"] as string[]).includes(p)?p as AiPlan:"FREE"};
const sha=(v:unknown)=>crypto.createHash("sha256").update(JSON.stringify(v)).digest("hex");
const redactPII=(v:string)=>v.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,"[email]").replace(/(?:\+?\d[\d\s().-]{7,}\d)/g,"[phone]");
const maxFor=(op:AiOperation,key:string)=>op==="CV_INTELLIGENCE"&&key==="cvText"?16000:4000;
const INPUT_KEYS:Record<AiOperation,string[]>={
  OFFER_INTELLIGENCE:["jobTitle","jobDescription","company","location","contract","skills"], CV_INTELLIGENCE:["cvText","targetRole","jobDescription"], MATCHING:["jobTitle","jobDescription","jobId","matchSignals"],
  APPLICATION_COPILOT:["jobTitle","jobDescription"], APPLICATION_STRATEGY:["jobTitle","jobDescription","applicationId","stage"], LEARNING:["goal","timePerWeek","targetRole","skillGaps"],
  INTERVIEW:["answer","difficulty","role","jobDescription","company"], CAREER_COMPANION:["goal","blocker","targetRole","horizon"], NOTIFICATION:["signalType","opportunityId","reason","urgency"], PAYMENT_SMS_INTELLIGENCE:[]
};
const sanitizeInput=(op:AiOperation,input:any)=>{if(!input||typeof input!=="object")return {};return Object.fromEntries((INPUT_KEYS[op]||[]).filter(k=>typeof input[k]==="string"||typeof input[k]==="number"||Array.isArray(input[k])).map(k=>[k,Array.isArray(input[k])?input[k].slice(0,20).map((x:any)=>redactPII(String(x)).slice(0,1000)):typeof input[k]==="string"?redactPII(String(input[k])).slice(0,maxFor(op,k)):input[k]]));};

export async function runAiGateway(req:NextRequest, raw:string, input:any={}):Promise<GatewayResult>{
  const op=normalize(raw); if(!op)return {ok:false,status:400,message:"Opération IA inconnue."};
  const auth=await getAuthUser(req); if(!auth)return {ok:false,status:401,message:"Session requise."};
  const sb=adminClient(); const user=await ensureUser(sb,auth);
  const {data:sub}=await sb.from("Subscription").select("planCode,status").eq("userId",user.id).in("status",["ACTIVE","TRIAL"]).order("createdAt",{ascending:false}).limit(1).maybeSingle();
  const plan=planOf(sub),cost=AI_OPERATION_COST[op],quota=AI_CREDITS_BY_PLAN[plan];
  const safeInput=sanitizeInput(op,input);
  const built=await buildJiaContext(sb,user.id,{operation:op,input:safeInput});
  if(built.error||!built.context)return {ok:false,status:500,message:built.error||"Contexte J’IA indisponible."};
  const context=built.context;
  const started=Date.now(),requestHash=sha({op,input:safeInput,context:{profile:context.profile,skills:context.skills,experiences:context.experiences,memory:context.memory,behavior:context.behavior}});
  const {data:reservation,error:reservationError}=await sb.rpc("reserve_ai_credit",{p_user_id:user.id,p_plan_code:plan,p_operation:op,p_cost:cost,p_request_hash:requestHash});
  if(reservationError)return {ok:false,status:500,message:reservationError.message};
  const row=Array.isArray(reservation)?reservation[0]:reservation;
  if(!row?.allowed){
    const upgradeSuggestion = await maybeCreateJiaUpgradeNudge(sb,user.id,plan,"AI_CREDITS",`La tâche demandée nécessite encore des crédits IA, mais le quota de ta formule est atteint.`,`Continuer les analyses J’IA au-delà du quota inclus`,plan === "FREE" ? "START" : plan === "START" ? "PREMIUM" : "PRO");
    const quotaMessage = plan === "FREE" ? `Le bonus J’IA de bienvenue est épuisé (${Number(row?.used_credits||0)}/${quota} crédits).` : `Quota IA mensuel atteint (${Number(row?.used_credits||0)}/${quota} crédits).`;
    return {ok:false,status:429,message:quotaMessage,upgradeSuggestion};
  }
  const usageId=String(row.usage_id);
  const supabaseUrl=process.env.NEXT_PUBLIC_SUPABASE_URL; const supabaseKey=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY; const authorization=req.headers.get("authorization");
  if(!supabaseUrl||!supabaseKey||!authorization)return {ok:false,status:500,message:"Runtime Supabase IA non configuré."};
  const providerResponse=await fetch(`${supabaseUrl.replace(/\/$/,"")}/functions/v1/ai-core`,{method:"POST",headers:{Authorization:authorization,apikey:supabaseKey,"Content-Type":"application/json"},body:JSON.stringify({operation:op,input:safeInput,context,priority:"BALANCED"}),cache:"no-store",signal:AbortSignal.timeout(35000)});
  const orchestration=await providerResponse.json().catch(()=>({}));
  if(!providerResponse.ok||!orchestration?.ok)return {ok:false,status:502,message:String(orchestration?.message||"Runtime IA indisponible.").slice(0,300)};
  const {error:updateError}=await sb.from("AiUsage").update({provider:orchestration.provider,model:orchestration.model,latencyMs:Date.now()-started,success:true}).eq("id",usageId).eq("userId",user.id);
  if(updateError)return {ok:false,status:500,message:updateError.message};
  const output:any=orchestration.output&&typeof orchestration.output==="object"?orchestration.output:{};
  const confidence=output.confidence==="HIGH"||output.confidence==="MEDIUM"||output.confidence==="LOW"?output.confidence:"MEDIUM";
  const traceBase={userId:user.id,actorRole:String(user.role),entityType:"AI_OPERATION",entityId:usageId,confidence,evidence:[{operation:op,provider:orchestration.provider,model:orchestration.model,requestHash,memorySignals:context.memory.length,eventSignals:context.behavior.eventCount}],metadata:{operation:op,credits:cost,attempts:orchestration.attempts,fallbackUsed:orchestration.fallbackUsed,latencyMs:Date.now()-started}};
  const observation=await sb.from("JiaIntelligenceTrace").insert({...traceBase,stage:"OBSERVATION",title:`J’IA — ${op}`,content:`Exécution de l’opération ${op}.`,sourceType:"AI_GATEWAY",sourceRef:"lib/aiGateway.ts",status:"RECORDED"}).select("id").single();
  if(!observation.error&&observation.data?.id){
    const actions=Array.isArray(output.suggestedActions)?output.suggestedActions:[];
    await sb.from("JiaIntelligenceTrace").insert({...traceBase,parentId:observation.data.id,stage:"RECOMMENDATION",title:`Résultat J’IA — ${op}`,content:JSON.stringify(orchestration.output).slice(0,12000),sourceType:"AI_GATEWAY",sourceRef:"lib/aiGateway.ts",status:actions.length?"PENDING_APPROVAL":"RECORDED",metadata:{...traceBase.metadata,suggestedActions:actions.slice(0,10),tracePolicy:"SUMMARY_ONLY"}});
  }
  await sb.from("AuditLog").insert({userId:user.id,action:"AI_OPERATION",entityType:"AiUsage",metadata:{operation:op,credits:cost,provider:orchestration.provider,model:orchestration.model,attempts:orchestration.attempts,fallbackUsed:orchestration.fallbackUsed,requestHash,memorySignals:context.memory.length,eventSignals:context.behavior.eventCount,consent:context.behavior.consented}});
  return {ok:true,operation:op,credits:cost,remaining:Number(row.remaining_credits),provider:orchestration.provider,aiName:JIA_NAME,output:orchestration.output};
}
