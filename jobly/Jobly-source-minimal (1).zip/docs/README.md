# Jobly — documentation essentielle

Cette archive réunit le code source minimal et une sélection de documents de référence issus de la branche `main`.

## Documents inclus
- Configuration, sécurité, ATS et design system
- Mission Afrique : matrice et audit du moteur de sources
- J’IA 360 : doctrine, master plan, spécifications, cerveau cognitif et Internet Brain
- Career Journey : spécification et état d’implémentation
- Recruitment 360 : audit final et lot 11
- Mobility : blueprint, architecture cible et remédiation P1
- Exploitation : runbook base de données, durcissement Supabase, paiements SMS
- Déploiement : Vercel, Supabase et passage en production

Les rapports historiques redondants, journaux, captures, images, vidéos, modèles 3D et archives binaires ne sont pas inclus.
