import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (file) => readFileSync(path.join(root, file), "utf8");

test("Community detail sends the Supabase bearer session to API routes", () => {
  const page = read("app/communities/[id]/page.tsx");
  assert.match(page, /communityAuthHeaders/);
  assert.match(page, /Authorization: `Bearer/);
  assert.match(page, /headers: \{ \.\.\.headers, "Content-Type": "application\/json" \}/);
});

test("Both Community write routes share the moderation guard", () => {
  const nested = read("app/api/community/[id]/posts/route.ts");
  const central = read("app/api/community/posts/route.ts");
  const guard = read("lib/community/moderation.ts");
  assert.match(nested, /moderateCommunityMessage/);
  assert.match(central, /moderateCommunityMessage/);
  assert.match(guard, /inspectCommunityMessage/);
  assert.match(nested, /membership\.role === "BANNED"/);
  assert.match(central, /membership\.role === "BANNED"/);
});

test("Community membership cannot reactivate a banned member", () => {
  const route = read("app/api/community/[id]/membership/route.ts");
  assert.match(route, /existing\?\.role === "BANNED"/);
  assert.match(route, /community\.status !== "ACTIVE"/);
});

test("Bon Plans feed returns persisted interaction and comment counts", () => {
  const route = read("app/api/bon-plans/route.ts");
  assert.match(route, /from\("BonPlanInteraction"\)/);
  assert.match(route, /from\("BonPlanComment"\)/);
  assert.match(route, /viewerLiked/);
  assert.match(route, /viewerSaved/);
  assert.match(route, /likeCount/);
  assert.match(route, /commentCount/);
});

test("Bon Plans interactions reject unpublished, future and expired content", () => {
  const route = read("app/api/bon-plans/[id]/interactions/route.ts");
  assert.match(route, /plan\.status !== "PUBLISHED"/);
  assert.match(route, /plan\.startsAt && plan\.startsAt > now/);
  assert.match(route, /plan\.expiresAt && plan\.expiresAt <= now/);
});

test("Campus feed is authenticated and applies the canonical Jobly freshness rule", () => {
  const route = read("app/api/campus/opportunities/route.ts");
  const page = read("app/campus/page.tsx");
  assert.match(route, /getAuthUser\(request\)/);
  assert.match(route, /resolveEffectivePublicationDate/);
  assert.match(route, /JobHarvestCapture/);
  assert.match(page, /\/api\/campus\/opportunities/);
  assert.match(page, /Authorization: `Bearer/);
});

test("Community, Bons Plans and Campus translations exist in French and English", () => {
  const dict = read("lib/i18n/dictionary.ts");
  for (const key of [
    "community.page.title",
    "community.detail.join",
    "bonplans.page.emptyTitle",
    "bonplans.pillar.campusTitle",
    "campus.page.openOffer",
    "campus.page.institutionsTitle",
    "campus.page.institutionMembers",
    "bonplans.page.proposalPending",
    "bonplans.page.moderationTitle",
  ]) {
    assert.ok(dict.includes(`"${key}":`), `missing FR/EN dictionary key: ${key}`);
    assert.equal((dict.match(new RegExp(`"${key}":`, "g")) || []).length, 2, `key must exist once in each language: ${key}`);
  }
});

test("Bon Plans comments are real, authenticated on write and bounded", () => {
  const route = read("app/api/bon-plans/[id]/comments/route.ts");
  const page = read("app/bons-plans/page.tsx");
  assert.match(route, /from\("BonPlanComment"\)/);
  assert.match(route, /getAuthUser\(request\)/);
  assert.match(route, /content\.length > 1000/);
  assert.match(page, /\/comments/);
  assert.match(page, /commentOnPlan/);
  assert.match(page, /commentsByPlan/);
});

test("Community reactions and comments use persisted tables and real endpoints", () => {
  const reactions = read("app/api/community/[id]/posts/[postId]/reactions/route.ts");
  const comments = read("app/api/community/[id]/posts/[postId]/comments/route.ts");
  const page = read("app/communities/[id]/page.tsx");
  assert.match(reactions, /CommunityPostReaction/);
  assert.match(comments, /CommunityPostComment/);
  assert.match(page, /reactToPost/);
  assert.match(page, /commentOnPost/);
});

test("Campus institutional directory uses real active institutions and membership records", () => {
  const route = read("app/api/campus/institutions/route.ts");
  const page = read("app/campus/page.tsx");
  assert.match(route, /getAuthUser\(request\)/);
  assert.match(route, /from\("Institution"\)/);
  assert.match(route, /from\("InstitutionMember"\)/);
  assert.match(route, /\.eq\("active", true\)/);
  assert.match(route, /\\bdemo\\b/i);
  assert.match(route, /memberCount/);
  assert.match(page, /\/api\/campus\/institutions/);
  assert.match(page, /campus-institutions-title/);
  assert.match(page, /institutionCount/);
});

test("Bon Plans suggestions enter review and never publish directly", () => {
  const route = read("app/api/bon-plans/route.ts");
  const post = route.slice(route.indexOf("export async function POST"));
  const page = read("app/bons-plans/page.tsx");
  assert.match(post, /status: "PENDING_REVIEW"/);
  assert.match(post, /parseOptionalHttpUrl/);
  assert.match(post, /parseOptionalDate/);
  assert.doesNotMatch(post, /status: "PUBLISHED"/);
  assert.match(page, /submitProposal/);
  assert.match(page, /proposalPending/);
});

test("Bon Plans decisions require the active root AdminIdentity", () => {
  const queue = read("app/api/bon-plans/moderation/route.ts");
  const decision = read("app/api/bon-plans/[id]/moderation/route.ts");
  const page = read("app/bons-plans/page.tsx");
  assert.ok(queue.includes('String(user.role).toUpperCase() !== "ADMIN"'));
  assert.ok(queue.includes('from("AdminIdentity")'));
  assert.ok(queue.includes("identity?.active"));
  assert.ok(decision.includes('String(moderator.role).toUpperCase() !== "ADMIN"'));
  assert.ok(decision.includes('from("AdminIdentity")'));
  assert.ok(decision.includes("identity?.active"));
  assert.doesNotMatch(decision, /MODERATOR/);
  assert.match(decision, /status !== "PENDING_REVIEW"/);
  assert.match(decision, /announceEventToCommunities/);
  assert.match(page, /moderatePlan/);
  assert.match(page, /bonplans-moderation-title/);
});


test("ADMIN 360 operational consoles are wired to authenticated, root-owned endpoints", () => {
  const catalog = read("lib/adminWorkspaceCatalog.ts");
  const shell = read("components/admin/AdminShell.tsx");
  const supportPublic = read("app/api/support/tickets/route.ts");
  const supportAdmin = read("app/api/admin/support/tickets/route.ts");
  const supportUpdate = read("app/api/admin/support/tickets/[id]/route.ts");
  const finance = read("app/api/admin/finance/overview/route.ts");
  const analyst = read("lib/adminAnalytics360.ts");
  const communityReport = read("app/api/community/[id]/posts/[postId]/report/route.ts");
  const communityQueue = read("app/api/admin/moderation/community/route.ts");
  const communityDecision = read("app/api/admin/moderation/community/[id]/route.ts");

  for (const code of ["SUPPORT", "FINANCE", "MODERATOR", "ANALYST"]) assert.ok(catalog.includes(code));
  for (const href of ["/admin/support", "/admin/finance", "/admin/community", "/admin/analytics", "/admin/accounts"]) assert.ok(shell.includes(href));
  assert.match(supportPublic, /getAuthUser\(request\)/);
  assert.match(supportAdmin, /from\("AdminIdentity"\)/);
  assert.match(supportAdmin, /identity\?\.active/);
  assert.match(supportUpdate, /from\("AuditLog"\)/);
  assert.match(finance, /from\("Payment"\)/);
  assert.match(finance, /readTable\(db, "PaymentSmsReceipt"/);
  assert.match(finance, /readTable\(db, "EventManualPaymentSubmission"/);
  assert.match(finance, /readTable\(db, "Subscription"/);
  assert.match(finance, /readTable\(db, "Commission"/);
  assert.match(analyst, /count:\s*count \?\? 0/);
  assert.match(analyst, /available: false, count: null/);
  assert.match(analyst, /community_posts/);
  assert.match(communityReport, /from\("AdminCommunityReport"\)/);
  assert.match(communityQueue, /from\("AdminIdentity"\)/);
  assert.match(communityDecision, /from\("AdminIdentity"\)/);
  assert.match(communityDecision, /COMMUNITY_MODERATION_/);
});

test("ADMIN 360 schema protects managed accounts, support records and community reports", () => {
  const managed = read("supabase/migrations/20261106115000_admin_managed_accounts.sql");
  const operations = read("supabase/migrations/20261106123000_admin_support_community_operations.sql");
  const schema = read("packages/database/prisma/schema.prisma");
  for (const table of ["AdminManagedAccount", "AdminSupportTicket", "AdminSupportTicketMessage", "AdminCommunityReport"]) {
    assert.ok(schema.includes("model " + table));
  }
  for (const table of ["AdminManagedAccount", "AdminSupportTicket", "AdminSupportTicketMessage", "AdminCommunityReport"]) {
    const migration = table === "AdminManagedAccount" ? managed : operations;
    assert.ok(migration.includes('alter table public."' + table + '" enable row level security'));
    assert.ok(migration.includes('revoke all on table public."' + table + '" from public, anon, authenticated'));
    assert.ok(migration.includes('grant all on table public."' + table + '" to service_role'));
  }
});
