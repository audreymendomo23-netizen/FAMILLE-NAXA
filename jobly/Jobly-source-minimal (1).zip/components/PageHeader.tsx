"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import JoblyLogo from "./JoblyLogo";
import { useI18n } from "@/lib/i18n";
import { getSupabaseClient } from "@/lib/supabase";

type Role = "talent" | "recruiter" | "partner";

const HOME: Record<Role, string> = { talent: "/dashboard", recruiter: "/recruiter", partner: "/partner" };
const PROFILE: Record<Role, string> = { talent: "/talent/profile", recruiter: "/recruiter/profile", partner: "/partner/profile" };

/** Déduit l’écosystème : prop explicite > thème > libellé d’eyebrow (FR/EN) > URL courante. */
function resolveRole(role: Role | undefined, theme: string, eyebrow: string | undefined, pathname: string): Role {
  if (role) return role;
  if (theme === "talent") return "talent";
  if (/^(recruiter|recruteur)$/i.test((eyebrow ?? "").trim())) return "recruiter";
  if (/^(partner|partenaire)$/i.test((eyebrow ?? "").trim())) return "partner";
  if (pathname.startsWith("/recruiter")) return "recruiter";
  if (pathname.startsWith("/partner")) return "partner";
  return "talent";
}

export default function PageHeader({
  label,
  eyebrow,
  initial = "•",
  avatarUrl,
  onBack,
  theme = "default",
  role,
  transparent = false,
}: {
  label: string;
  eyebrow?: string;
  initial?: string;
  avatarUrl?: string;
  onBack?: () => void;
  theme?: "default" | "talent";
  role?: Role;
  transparent?: boolean;
}) {
  const router = useRouter();
  const pathname = usePathname() ?? "";
  const { t } = useI18n();
  const [canSwitchAdmin, setCanSwitchAdmin] = useState(false);
  const eco = resolveRole(role, theme, eyebrow, pathname);

  useEffect(() => {
    let alive = true;
    setCanSwitchAdmin(false);
    if (pathname.startsWith("/admin")) return () => { alive = false; };
    (async () => {
      const session = await getSupabaseClient().auth.getSession();
      const token = session.data.session?.access_token;
      if (!token) return;
      const response = await fetch("/api/me", { headers: { Authorization: "Bearer " + token }, cache: "no-store" });
      const body = await response.json().catch(() => ({}));
      if (alive && response.ok) setCanSwitchAdmin(Boolean(body.capabilities?.canSwitchAdmin));
    })().catch(() => {});
    return () => { alive = false; };
  }, [pathname]);

  async function switchToAdmin() {
    const session = await getSupabaseClient().auth.getSession();
    const token = session.data.session?.access_token;
    if (!token) return;
    const response = await fetch("/api/admin/context", {
      method: "POST",
      headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "ADMIN" }),
    });
    if (response.ok) router.push("/admin");
  }

  return (
    <header className={`sticky top-0 z-30 px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))] sm:px-6 ${transparent ? "border-b-0 bg-transparent shadow-none backdrop-blur-0" : "border-b border-line bg-white/95 shadow-[0_6px_24px_rgba(10,25,49,.04)] backdrop-blur-xl"}`}>
      <div className="mx-auto flex max-w-5xl items-center justify-between">
        <button
          type="button"
          onClick={() => (onBack ? onBack() : router.push(HOME[eco]))}
          aria-label={t("header.backHome")}
          className="jobly-focus flex min-h-[44px] items-center gap-2 rounded-xl"
        >
          <JoblyLogo size="header" showTagline />
        </button>

        <div className="flex items-center gap-2.5">
          {canSwitchAdmin && (
            <button type="button" onClick={switchToAdmin} aria-label="Ouvrir l'espace administrateur" title="Espace ADMIN" className="jobly-focus rounded-full border border-[#DCE4F0] bg-[#10264A] px-3 py-2 text-[10px] font-black text-white transition hover:bg-[#1A3B70]">
              ADMIN ↗
            </button>
          )}
          <button
            type="button"
            onClick={() => router.push("/settings")}
            aria-label="Paramètres et sauvegarde"
            title="Paramètres"
            className="jobly-focus flex h-11 w-11 items-center justify-center rounded-full bg-slate-100 text-[#0A1931] transition active:scale-95"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.7 2.94-.08-.03a1.7 1.7 0 0 0-1.8.25l-.07.05h-3.4l-.02-.08a1.7 1.7 0 0 0-1.28-1.32l-.09-.02-1.7-2.94.06-.06A1.7 1.7 0 0 0 10 14l-.03-.09v-3.4l.08-.02a1.7 1.7 0 0 0 1.32-1.28l.02-.09 2.94-1.7.06.06a1.7 1.7 0 0 0 1.88.34l.06-.03 2.94 1.7-.03.08a1.7 1.7 0 0 0 .25 1.8l.05.07v3.4l-.08.02a1.7 1.7 0 0 0-1.32 1.28l-.02.09Z"/>
            </svg>
          </button>

          <button
            type="button"
            onClick={() => router.push("/support")}
            aria-label="Ouvrir le Support Jobly"
            title="Aide & Support"
            className="jobly-focus flex h-11 w-11 items-center justify-center rounded-full bg-slate-100 text-[#0A1931] transition active:scale-95"
          >
            <span aria-hidden="true" className="text-lg font-black">?</span>
          </button>

          <button
            type="button"
            onClick={() => router.push("/notifications")}
            aria-label={t("header.notifications")}
            className="jobly-focus relative flex h-11 w-11 items-center justify-center rounded-full bg-canari-blue-soft text-canari-blue transition active:scale-95"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
          </button>

          <button type="button" onClick={() => router.push(PROFILE[eco])} aria-label={t("header.openProfile")} className="jobly-focus rounded-full">
            {avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={avatarUrl} alt={t("header.profilePhoto")} className="h-11 w-11 rounded-full border-2 border-white object-cover shadow-[0_4px_12px_rgba(11,31,75,0.12)]" />
            ) : (
              <span className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white bg-canari text-sm font-black text-ink shadow-[0_4px_12px_rgba(11,31,75,0.12)]">
                {initial}
              </span>
            )}
          </button>
        </div>
      </div>

      {(eyebrow || label) && (
        <div className="mx-auto mt-2 max-w-5xl">
          {eyebrow && <div className="text-[11px] font-black uppercase tracking-wider text-canari-blue">{eyebrow}</div>}
          {label && <div className="text-[13px] font-semibold text-muted">{label}</div>}
        </div>
      )}
    </header>
  );
}
