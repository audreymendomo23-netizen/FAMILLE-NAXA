-- Applied to JOBLY-PROD as 20261106075217 / jobly_device_session_reuse_guard.
-- Prevents a stale browser session from reclaiming the same device identity.

create or replace function public.register_jobly_device_session(
  p_auth_user_id text,
  p_auth_session_id uuid,
  p_device_id text,
  p_device_label text,
  p_user_agent text default null
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_user_id text;
  v_existing public."UserDeviceSession"%rowtype;
  v_revoked text[];
  v_current_revoked timestamptz;
begin
  if p_auth_user_id is null or p_auth_session_id is null
     or p_device_id is null or length(p_device_id) < 1 or length(p_device_id) > 160 then
    return jsonb_build_object('registered', false, 'allowed', false, 'reason', 'INVALID_DEVICE');
  end if;

  select "id" into v_user_id from public."User" where "authUserId" = p_auth_user_id limit 1;
  if v_user_id is null then
    return jsonb_build_object('registered', false, 'allowed', true, 'reason', 'USER_NOT_PROVISIONED');
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_user_id, 0));

  select * into v_existing
  from public."UserDeviceSession"
  where "userId" = v_user_id and "deviceId" = p_device_id
  for update;

  if found then
    if v_existing."authSessionId" = p_auth_session_id then
      if v_existing."revokedAt" is not null then
        return jsonb_build_object('registered', true, 'allowed', false, 'reason', 'DEVICE_REVOKED');
      end if;
      update public."UserDeviceSession"
        set "lastSeenAt" = now(),
            "deviceLabel" = left(coalesce(nullif(trim(p_device_label), ''), "deviceLabel"), 100),
            "userAgent" = left(coalesce(p_user_agent, "userAgent"), 1000)
      where "id" = v_existing."id";
    else
      if exists (select 1 from auth.sessions where id = v_existing."authSessionId") then
        return jsonb_build_object('registered', true, 'allowed', false, 'reason', 'DEVICE_SESSION_REPLACED');
      end if;
      update public."UserDeviceSession"
        set "authSessionId" = p_auth_session_id,
            "deviceLabel" = left(coalesce(nullif(trim(p_device_label), ''), 'Appareil'), 100),
            "userAgent" = left(coalesce(p_user_agent, ''), 1000),
            "createdAt" = now(),
            "lastSeenAt" = now(),
            "revokedAt" = null
      where "id" = v_existing."id";
    end if;
  else
    insert into public."UserDeviceSession"
      ("userId", "authSessionId", "deviceId", "deviceLabel", "userAgent")
    values (v_user_id, p_auth_session_id, p_device_id,
            left(coalesce(nullif(trim(p_device_label), ''), 'Appareil'), 100),
            left(coalesce(p_user_agent, ''), 1000));
  end if;

  with ranked as (
    select "id", row_number() over (order by "createdAt" desc, "lastSeenAt" desc, "id" desc) as position
    from public."UserDeviceSession"
    where "userId" = v_user_id and "revokedAt" is null
  )
  update public."UserDeviceSession" as sessions
    set "revokedAt" = now()
  from ranked
  where sessions."id" = ranked."id" and ranked.position > 3;

  select "revokedAt" into v_current_revoked
  from public."UserDeviceSession"
  where "userId" = v_user_id and "deviceId" = p_device_id and "authSessionId" = p_auth_session_id;

  select coalesce(array_agg("deviceId"), array[]::text[]) into v_revoked
  from public."UserDeviceSession"
  where "userId" = v_user_id and "revokedAt" is not null
    and "revokedAt" > now() - interval '2 minutes';

  return jsonb_build_object('registered', true, 'allowed', v_current_revoked is null,
    'activeDeviceLimit', 3, 'revokedDeviceIds', v_revoked);
end;
$$;

revoke all on function public.register_jobly_device_session(text, uuid, text, text, text) from public, anon, authenticated;
grant execute on function public.register_jobly_device_session(text, uuid, text, text, text) to service_role;
