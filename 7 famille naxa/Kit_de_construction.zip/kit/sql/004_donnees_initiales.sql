-- =====================================================================
-- 004 — Données initiales (prix proposés [P] : à tester auprès de 5 ou 6 commerçants avant de les figer)
-- NON APPLIQUÉ.
-- =====================================================================
insert into plan_prices (app, tier, monthly_price, extra_point_price, offline_days) values
 ('kiosko', 'essentiel', 1000, null, 7), ('kiosko', 'services', 1500, 500, 7), ('kiosko', 'complet', 3000, 500, 14),
 ('bootik', 'essentiel', 1000, null, 7), ('bootik', 'pro', 3000, 500, 7), ('bootik', 'reseau', 6000, null, 14),
 ('zipple', 'essentiel', 1000, null, 7), ('zipple', 'pro', 3000, 500, 7), ('zipple', 'reseau', 6000, null, 14),
 ('naxa_services', 'essentiel', 1000, null, 7), ('naxa_services', 'pro', 3000, 500, 7), ('naxa_services', 'reseau', 6000, null, 14),
 ('cotiz', 'essentiel', 500, null, 7), ('cotiz', 'pro', 1500, null, 7), ('cotiz', 'reseau', 3000, null, 14),
 ('loyable', 'essentiel', 1000, null, 7), ('loyable', 'pro', 3000, null, 7), ('loyable', 'reseau', 6000, null, 14),
 ('naxa_hotel', 'essentiel', 3000, null, 7), ('naxa_hotel', 'pro', 8000, 2000, 7), ('naxa_hotel', 'reseau', 20000, null, 14);

insert into app_versions (app, min_version, latest_version) values
 ('kiosko', 1, 1), ('bootik', 1, 1), ('zipple', 1, 1), ('naxa_services', 1, 1), ('cotiz', 1, 1), ('loyable', 1, 1), ('naxa_hotel', 1, 1);

insert into app_settings (key, value) values
 ('sync_grace_days', '0'::jsonb),          -- [O] délai de grâce côté serveur après l'échéance
 ('welcome_window_hours', '48'::jsonb),    -- offre de bienvenue : paiement dans les 48 h après la fin de la période
 ('free_months_cap_year', '3'::jsonb),     -- plafond de mois offerts par an
 ('blocked_recording_days', '60'::jsonb);  -- l'enregistrement local s'arrête après 60 jours de blocage
