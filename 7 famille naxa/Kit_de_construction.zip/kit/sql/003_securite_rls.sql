-- =====================================================================
-- 003 — Fonctions de sécurité et règles RLS (socle commun)
-- NON APPLIQUÉ, NON EXÉCUTÉ sur PostgreSQL. Principes :
--   * un point ne voit que ses lignes ; le compte mère (rôle owner global) voit tous ses points ;
--   * l'administration n'a AUCUNE politique sur les tables de transactions : elle ne voit que des chiffres agrégés (admin_kpis) ;
--   * un point dont l'abonnement est échu ne peut ni lire ni écrire (sauf écran de paiement : subscriptions, payments).
-- =====================================================================

create or replace function current_client() returns uuid language sql stable security definer set search_path = public as $$
  select client_id from profiles where id = auth.uid()
$$;
create or replace function has_role(r role_code) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = r)
$$;
create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select has_role('admin')
$$;
-- Propriétaire : rôle owner sans point précis (voit tous les points de son client).
create or replace function is_owner() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = 'owner' and outlet_id is null)
$$;
create or replace function my_outlet_ids() returns setof uuid language sql stable security definer set search_path = public as $$
  select o.id from outlets o where is_owner() and o.client_id = current_client()
  union
  select ur.outlet_id from user_roles ur where ur.user_id = auth.uid() and ur.outlet_id is not null
$$;
-- Le point peut-il lire et écrire ? Abonnement non bloqué/suspendu et échéance (+ délai de grâce réglable, 0 par défaut) non dépassée. [O : délai de grâce à confirmer]
create or replace function outlet_sync_allowed(p_outlet uuid) returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((
    select s.status in ('trial', 'active', 'past_due')
       and now() <= s.due_at + make_interval(days => coalesce((select (value)::text::int from app_settings where key = 'sync_grace_days'), 0))
    from outlets o join subscriptions s on s.client_id = o.client_id and s.app = o.app
    where o.id = p_outlet
  ), false)
$$;
-- Empreinte de signature de l'APK connue ? (une empreinte inconnue = APK modifié : synchronisation refusée et alerte à l'administration)
create or replace function signature_known(p_app app_id, p_fp text) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from known_signatures where app = p_app and fingerprint = p_fp)
$$;

-- Applique le modèle standard aux tables qui portent une colonne outlet_id.
-- allow_update = false pour les tables immuables (transactions issues de SMS : les corrections s'ajoutent comme écritures nouvelles).
-- Aucune politique de suppression : la suppression est douce (colonne deleted_at) ou impossible.
create or replace function apply_outlet_rls(tbl text, allow_update boolean default true) returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format('drop policy if exists p_sel on %I', tbl);
  execute format('drop policy if exists p_ins on %I', tbl);
  execute format('drop policy if exists p_upd on %I', tbl);
  execute format('create policy p_sel on %I for select to authenticated using (outlet_id in (select my_outlet_ids()) and outlet_sync_allowed(outlet_id))', tbl);
  execute format('create policy p_ins on %I for insert to authenticated with check (outlet_id in (select my_outlet_ids()) and outlet_sync_allowed(outlet_id))', tbl);
  if allow_update then
    execute format('create policy p_upd on %I for update to authenticated using (outlet_id in (select my_outlet_ids()) and outlet_sync_allowed(outlet_id)) with check (outlet_id in (select my_outlet_ids()))', tbl);
  end if;
end $$;

-- Limite de 2 appareils actifs par point : le plus ancien est fermé au-delà (le propriétaire est notifié par l'application).
create or replace function limit_active_devices() returns trigger language plpgsql security definer set search_path = public as $$
begin
  update devices set active = false
  where id in (select id from devices where outlet_id = new.outlet_id and active order by created_at desc offset 2);
  return null;
end $$;
create trigger trg_limit_devices after insert on devices for each row execute function limit_active_devices();

-- Verrouillage après 5 tentatives échouées (appelée par une fonction serveur avec la clé de service, jamais par l'application).
create or replace function register_login_result(p_user uuid, p_success boolean) returns void language plpgsql security definer set search_path = public as $$
begin
  if p_success then update profiles set failed_attempts = 0, locked_until = null where id = p_user;
  else update profiles set failed_attempts = failed_attempts + 1,
        locked_until = case when failed_attempts + 1 >= 5 then now() + interval '15 minutes' else locked_until end where id = p_user;
  end if;
end $$;
revoke all on function register_login_result(uuid, boolean) from public, anon, authenticated;

-- Indicateurs agrégés de l'administration (jamais de transactions détaillées).
create or replace function admin_kpis() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'réservé à l''administration'; end if;
  return jsonb_build_object(
    'clients_actifs', (select count(*) from subscriptions where status = 'active'),
    'essais_en_cours', (select count(*) from subscriptions where status = 'trial'),
    'echeances_7j', (select count(*) from subscriptions where due_at between now() and now() + interval '7 days'),
    'paiements_a_valider', (select count(*) from payments where status in ('pending', 'needs_review')),
    'revenu_mois', (select coalesce(sum(amount), 0) from payments where status in ('auto_matched', 'validated') and paid_at >= date_trunc('month', now())),
    'depart_mois', (select count(*) from subscriptions where status in ('blocked', 'suspended') and due_at >= date_trunc('month', now())));
end $$;

-- ---------------------------------------------------------------- RLS des tables du socle
alter table organizations enable row level security; alter table clients enable row level security; alter table profiles enable row level security;
alter table outlets enable row level security; alter table user_roles enable row level security; alter table client_apps enable row level security;
alter table devices enable row level security; alter table sales_reps enable row level security; alter table partners enable row level security;
alter table plan_prices enable row level security; alter table subscriptions enable row level security; alter table payments enable row level security;
alter table payment_log enable row level security; alter table promo_codes enable row level security; alter table referrals enable row level security;
alter table partner_commissions enable row level security; alter table notifications enable row level security; alter table notification_preferences enable row level security;
alter table audit_log enable row level security; alter table app_versions enable row level security; alter table known_signatures enable row level security;
alter table parser_rules enable row level security; alter table support_tickets enable row level security; alter table app_settings enable row level security; alter table backups enable row level security;

-- Profils : lecture de soi-même ; seules les colonnes non sensibles sont modifiables par l'utilisateur.
create policy profiles_sel on profiles for select to authenticated using (id = auth.uid() or is_admin());
create policy profiles_upd on profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
revoke update on profiles from authenticated; grant update (lang, full_name) on profiles to authenticated;
create policy profiles_admin on profiles for all to authenticated using (is_admin()) with check (is_admin());

create policy clients_sel on clients for select to authenticated using (id = current_client() or is_admin());
create policy clients_admin on clients for all to authenticated using (is_admin()) with check (is_admin());   -- création par l'administration seulement
create policy orgs_sel on organizations for select to authenticated using (id in (select org_id from clients where id = current_client()) or is_admin());
create policy orgs_admin on organizations for all to authenticated using (is_admin()) with check (is_admin());
create policy capps_sel on client_apps for select to authenticated using (client_id = current_client() or is_admin());
create policy capps_admin on client_apps for all to authenticated using (is_admin()) with check (is_admin());

create policy outlets_sel on outlets for select to authenticated using (id in (select my_outlet_ids()) or is_admin());
create policy outlets_ins on outlets for insert to authenticated with check ((is_owner() and client_id = current_client()) or is_admin());
create policy outlets_upd on outlets for update to authenticated using ((is_owner() and client_id = current_client()) or is_admin()) with check ((is_owner() and client_id = current_client()) or is_admin());
-- Le commercial voit les points de sa zone (champs d'identification, jamais de transactions) : policy sur outlets, pas sur les tables de transactions.
create policy outlets_rep on outlets for select to authenticated using (exists (select 1 from sales_reps r where r.user_id = auth.uid() and r.zone = outlets.city));

create policy roles_sel on user_roles for select to authenticated using (user_id = auth.uid() or is_admin() or (is_owner() and outlet_id in (select my_outlet_ids())));
create policy roles_owner on user_roles for insert to authenticated with check (is_admin() or (is_owner() and outlet_id in (select my_outlet_ids()) and role in ('manager', 'cashier', 'staff', 'accountant')));
create policy roles_admin on user_roles for all to authenticated using (is_admin()) with check (is_admin());

create policy devices_own on devices for select to authenticated using (user_id = auth.uid() or is_admin() or (is_owner() and outlet_id in (select my_outlet_ids())));
create policy devices_ins on devices for insert to authenticated with check (user_id = auth.uid());
create policy devices_upd on devices for update to authenticated using (user_id = auth.uid() or (is_owner() and outlet_id in (select my_outlet_ids())) or is_admin());  -- déconnexion à distance

-- Abonnement : toujours lisible par le client même échu (écran de paiement) ; modifié par l'administration seulement.
create policy subs_sel on subscriptions for select to authenticated using (client_id = current_client() or is_admin());
create policy subs_admin on subscriptions for all to authenticated using (is_admin()) with check (is_admin());
create policy prices_sel on plan_prices for select to authenticated using (true);
create policy prices_admin on plan_prices for all to authenticated using (is_admin()) with check (is_admin());
-- Paiement : le client peut DÉCLARER un paiement (« J'ai payé ») en statut pending, même échu ; seule l'administration le valide.
create policy pay_sel on payments for select to authenticated using (subscription_id in (select id from subscriptions where client_id = current_client()) or is_admin());
create policy pay_ins on payments for insert to authenticated with check (status = 'pending' and subscription_id in (select id from subscriptions where client_id = current_client()));
create policy pay_admin on payments for update to authenticated using (is_admin()) with check (is_admin());
create policy paylog_admin on payment_log for select to authenticated using (is_admin());
create policy promo_admin on promo_codes for all to authenticated using (is_admin()) with check (is_admin());
create policy ref_own on referrals for select to authenticated using (referrer_client = current_client() or referee_client = current_client() or partner_user = auth.uid() or is_admin());
create policy ref_admin on referrals for all to authenticated using (is_admin()) with check (is_admin());
create policy comm_own on partner_commissions for select to authenticated using (partner_user = auth.uid() or is_admin());
create policy partners_own on partners for select to authenticated using (user_id = auth.uid() or is_admin());
create policy reps_own on sales_reps for select to authenticated using (user_id = auth.uid() or is_admin());

create policy notif_own on notifications for select to authenticated using (user_id = auth.uid());
create policy notif_upd on notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy nprefs_own on notification_preferences for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Audit : ajout seulement, aucune modification ni suppression.
create policy audit_ins on audit_log for insert to authenticated with check (actor = auth.uid());
create policy audit_sel on audit_log for select to authenticated using (outlet_id in (select my_outlet_ids()) or is_admin());
revoke update, delete, truncate on audit_log from authenticated, anon;

create policy versions_sel on app_versions for select to authenticated using (true);
create policy versions_admin on app_versions for all to authenticated using (is_admin()) with check (is_admin());
create policy sig_admin on known_signatures for all to authenticated using (is_admin()) with check (is_admin());
create policy rules_sel on parser_rules for select to authenticated using (active);
create policy rules_admin on parser_rules for all to authenticated using (is_admin()) with check (is_admin());
create policy tickets_own on support_tickets for all to authenticated using (client_id = current_client() or is_admin()) with check (client_id = current_client() or is_admin());
create policy settings_admin on app_settings for all to authenticated using (is_admin()) with check (is_admin());
create policy backups_own on backups for select to authenticated using (outlet_id in (select my_outlet_ids()) or is_admin());
