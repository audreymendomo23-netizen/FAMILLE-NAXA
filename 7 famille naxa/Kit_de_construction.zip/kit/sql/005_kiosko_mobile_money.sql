-- =====================================================================
-- 005 — Kiosko (mobile money) : tables propres à l'application
-- NON APPLIQUÉ, NON EXÉCUTÉ. Chaque table porte outlet_id et reçoit le modèle RLS standard (voir 003).
-- Les textes bruts des SMS ne sont JAMAIS synchronisés : seuls les champs extraits le sont (cahier 6.8).
-- =====================================================================

create table networks (                 -- réseaux paramétrables (Orange Money, MTN MoMo, Wave…)
  id text primary key,                  -- 'om', 'momo', 'wave'
  name text not null, sender text not null, color_key text,
  active boolean not null default true
);
alter table networks enable row level security;
create policy networks_sel on networks for select to authenticated using (true);
create policy networks_admin on networks for all to authenticated using (is_admin()) with check (is_admin());

create table wallets (                  -- soldes par point : float par réseau, espèces, stock de crédit
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  kind text not null check (kind in ('float', 'cash', 'credit_stock', 'service')),
  network text references networks(id),
  label text,
  balance bigint not null default 0,
  low_threshold bigint,                 -- seuil minimum réglable
  request_target bigint,                -- montant cible à demander au livreur
  updated_at timestamptz not null default now(),
  unique (outlet_id, kind, network, label)
);

create table transactions (             -- IMMUABLE : une correction s'ajoute comme écriture nouvelle (corrects_id), jamais de modification
  id uuid primary key,                  -- généré par le téléphone : idempotence de la synchronisation
  outlet_id uuid not null references outlets(id) on delete cascade,
  network text references networks(id),
  nature text not null check (nature in ('depot', 'retrait', 'appro_float', 'destockage', 'c2c_sortie', 'c2c_entree', 'credit_appro', 'credit_vente', 'vente_sim', 'identification', 'otp_service', 'vente_libre', 'service_autre', 'correction')),
  amount bigint not null,
  fee bigint not null default 0,
  commission bigint not null default 0,
  balance_after bigint,                 -- solde indiqué par le SMS
  txid text,                            -- identifiant de transaction de l'opérateur
  counterparty_masked text,             -- numéro masqué
  occurred_at timestamptz not null,
  source op_source not null,
  status text not null default 'ok' check (status in ('ok', 'to_verify', 'shared_to_verify')),
  created_by uuid references profiles(id),
  corrects_id uuid references transactions(id),
  reason text,                          -- raison obligatoire pour une correction ou une annulation
  rule_id uuid, rule_version int,
  created_at timestamptz not null default now(),
  check (nature <> 'correction' or (corrects_id is not null and reason is not null))
);
create unique index tx_outlet_txid on transactions (outlet_id, txid) where txid is not null;   -- dédoublonnage par identifiant de transaction
create index tx_outlet_time on transactions (outlet_id, occurred_at desc);

create table balance_gaps (             -- trous dans la chaîne des soldes (6.11.3)
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  network text references networks(id),
  from_ts timestamptz not null, to_ts timestamptz not null,
  amount bigint not null,
  status text not null default 'open' check (status in ('open', 'resolved', 'justified')),
  justification text,
  created_at timestamptz not null default now(),
  unique (outlet_id, network, from_ts, to_ts)           -- une alerte par trou
);
create table cash_sessions (            -- ouverture et clôture de journée
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  opened_at timestamptz not null, closed_at timestamptz,
  opening_cash bigint not null, expected_cash bigint, counted_cash bigint,
  gap bigint generated always as (counted_cash - expected_cash) stored,
  opened_by uuid references profiles(id), closed_by uuid references profiles(id)
);
create table float_orders (             -- commandes de float : demandée, en route, reçue
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  network text references networks(id), amount bigint not null,
  status text not null default 'requested' check (status in ('requested', 'on_the_way', 'received')),
  requested_at timestamptz not null default now(), received_at timestamptz
);
create table contacts (                 -- livreur, chef secteur, support
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  kind text not null, name text not null, phone text not null
);
create table commission_rules (
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  network text references networks(id), nature text not null,
  rate_per_mille int not null check (rate_per_mille >= 0)       -- 15 = 1,5 %
);
create table expenses (
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  label text not null, category text, amount bigint not null, spent_at date not null
);
create table customers (
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  name text not null, phone text, notes text
);
create table credits (                  -- dettes et créances des clients réguliers
  id uuid primary key default gen_random_uuid(),
  outlet_id uuid not null references outlets(id) on delete cascade,
  customer_id uuid not null references customers(id),
  amount bigint not null, kind text not null check (kind in ('owed_to_me', 'i_owe')),
  due_on date, settled_at timestamptz
);
create table device_compat (            -- compatibilité par modèle de téléphone (tests terrain, 6.11.4) ; alimentée par l'administration
  model text primary key, brand text,
  status text not null check (status in ('works', 'works_with_settings', 'does_not_work')),
  settings_guide text, tested_at date
);
alter table device_compat enable row level security;
create policy compat_sel on device_compat for select to authenticated using (true);
create policy compat_admin on device_compat for all to authenticated using (is_admin()) with check (is_admin());

-- Modèle RLS standard. Les transactions sont immuables (pas de politique de mise à jour).
select apply_outlet_rls('wallets'); select apply_outlet_rls('transactions', false); select apply_outlet_rls('balance_gaps');
select apply_outlet_rls('cash_sessions'); select apply_outlet_rls('float_orders'); select apply_outlet_rls('contacts');
select apply_outlet_rls('commission_rules'); select apply_outlet_rls('expenses'); select apply_outlet_rls('customers'); select apply_outlet_rls('credits');
