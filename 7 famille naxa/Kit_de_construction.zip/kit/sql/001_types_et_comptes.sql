-- =====================================================================
-- 001 — Types et comptes (socle commun aux 7 applications)
-- PostgreSQL / Supabase. NON APPLIQUÉ, NON EXÉCUTÉ : à relire, puis à appliquer seulement avec accord explicite.
-- =====================================================================

create type app_id as enum ('kiosko', 'bootik', 'zipple', 'naxa_services', 'cotiz', 'loyable', 'naxa_hotel');
create type tier_id as enum ('essentiel', 'services', 'pro', 'complet', 'reseau');  -- 'services'/'complet' = paliers de Kiosko (grille v1.2)
create type role_code as enum ('admin', 'owner', 'manager', 'cashier', 'staff', 'accountant', 'sales_rep', 'partner');
create type sub_status as enum ('trial', 'active', 'past_due', 'blocked', 'suspended');
create type pay_status as enum ('pending', 'auto_matched', 'needs_review', 'validated', 'rejected');
create type op_source as enum ('sms_auto', 'sms_partage', 'import', 'manuel');

create table organizations (            -- compte mère : un propriétaire qui coiffe plusieurs points
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table clients (                  -- fiche client créée UNIQUEMENT par l'administration
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id),
  display_name text not null,
  phone text not null unique,           -- identifiant de connexion
  email text,
  lang text not null default 'fr' check (lang in ('fr', 'en')),
  status text not null default 'active' check (status in ('active', 'suspended')),
  notes text,
  created_by uuid,                      -- compte administrateur
  created_at timestamptz not null default now()
);

create table profiles (                 -- un profil par utilisateur d'authentification
  id uuid primary key references auth.users(id) on delete cascade,
  client_id uuid references clients(id),
  full_name text,
  phone text,
  lang text not null default 'fr' check (lang in ('fr', 'en')),
  must_change_password boolean not null default true,   -- changement obligatoire à la première connexion
  failed_attempts int not null default 0,
  locked_until timestamptz,                              -- blocage temporaire après 5 tentatives échouées
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table outlets (                  -- un point de vente, un hôtel, un bien ou un groupe de tontine (selon l'application)
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organizations(id),
  client_id uuid not null references clients(id),
  app app_id not null,
  profile_key text,                     -- profil métier (ex. 'depot_gaz', 'pressing', 'hotel')
  name text not null,
  city text, district text,
  lat double precision, lng double precision,           -- position enregistrée avec consentement
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index on outlets (client_id, app);

create table user_roles (               -- rôle d'un utilisateur, global (admin, partner…) ou sur un point
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  role role_code not null,
  outlet_id uuid references outlets(id) on delete cascade,
  unique (user_id, role, outlet_id)
);
create index on user_roles (user_id);

create table client_apps (              -- applications autorisées pour un client (choisies par l'administration)
  client_id uuid not null references clients(id) on delete cascade,
  app app_id not null,
  allowed boolean not null default true,
  primary key (client_id, app)
);

create table devices (                  -- jusqu'à 2 appareils actifs par point (le plus ancien est fermé au-delà)
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  outlet_id uuid references outlets(id) on delete cascade,
  app app_id not null,
  device_label text,
  fcm_token text,
  signature_fingerprint text,           -- empreinte de signature de l'APK, comparée à celles connues du serveur
  app_version int,
  active boolean not null default true,
  last_seen timestamptz,
  created_at timestamptz not null default now()
);
create index on devices (outlet_id, active);

create table sales_reps (user_id uuid primary key references profiles(id), zone text);
create table partners (
  user_id uuid primary key references profiles(id),
  referral_code text not null unique,
  payout_phone text,
  min_payout int not null default 5000
);
