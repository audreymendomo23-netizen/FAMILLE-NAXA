-- =====================================================================
-- 002 — Abonnement, paiements et tables transversales
-- NON APPLIQUÉ, NON EXÉCUTÉ.
-- =====================================================================

create table plan_prices (              -- prix mensuels, modifiables par l'administration (cahiers : tous [P], à tester)
  app app_id not null,
  tier tier_id not null,
  monthly_price int not null check (monthly_price >= 0),
  extra_point_price int,                -- null = pas de point supplémentaire pour ce palier
  offline_days int not null default 7,
  primary key (app, tier)
);

create table subscriptions (            -- UN abonnement par client ET par application
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references clients(id) on delete cascade,
  app app_id not null,
  tier tier_id not null,
  extra_points int not null default 0 check (extra_points >= 0),
  status sub_status not null default 'trial',
  period_start timestamptz not null default now(),
  due_at timestamptz not null,          -- échéance de la période accordée (essai ou forfait)
  free_months_granted_year int not null default 0,      -- plafond de 3 mois offerts par an
  provisional_used_for_period boolean not null default false,   -- accès provisoire de 24 h : une seule fois par période
  created_by uuid,
  created_at timestamptz not null default now(),
  unique (client_id, app)
);
create index on subscriptions (status, due_at);

create table payments (                 -- paiement d'abonnement déclaré par le client puis rapproché par le téléphone admin
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references subscriptions(id),
  txid text not null,                   -- identifiant de transaction de l'opérateur
  amount int not null check (amount > 0),
  payer_phone text,
  network text,
  reference text,                       -- référence unique affichée au client
  declared_at timestamptz not null default now(),   -- moment du clic « J'ai payé »
  paid_at timestamptz,                  -- horaire lu dans le SMS réel
  status pay_status not null default 'pending',
  months int,                           -- durée payée (1, 3, 6, 12)
  matched_by text,                      -- 'admin_phone' ou 'manual'
  validated_by uuid,
  rejected_reason text,
  created_at timestamptz not null default now()
);
-- Un même identifiant de transaction ne sert qu'une fois, y compris en cas de demandes simultanées.
create unique index payments_txid_unique on payments (txid);

create table payment_log (              -- journal complet : qui a validé, quand, avec quel SMS (le texte du SMS d'abonnement est conservé)
  id bigint generated always as identity primary key,
  payment_id uuid not null references payments(id),
  actor uuid,
  action text not null,
  sms_excerpt text,                     -- jamais d'OTP ni de PIN : le téléphone admin n'envoie que les champs utiles
  created_at timestamptz not null default now()
);

create table promo_codes (
  code text primary key,
  discount_percent int check (discount_percent between 0 and 100),
  free_months int not null default 0,
  max_uses int, used int not null default 0,
  valid_until timestamptz,
  active boolean not null default true
);
create table referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_client uuid references clients(id),
  referee_client uuid not null references clients(id),
  partner_user uuid references partners(user_id),
  first_real_payment_at timestamptz,    -- le mois de parrainage n'est accordé qu'après le premier paiement réel du filleul
  months_granted int not null default 0,
  check (referrer_client is not null or partner_user is not null),
  check (referrer_client is distinct from referee_client)       -- pas d'auto-parrainage
);
create table partner_commissions (
  id uuid primary key default gen_random_uuid(),
  partner_user uuid not null references partners(user_id),
  referral_id uuid not null unique references referrals(id),    -- une seule fois par point
  amount int not null default 100,
  status text not null default 'earned' check (status in ('earned', 'paid')),
  created_at timestamptz not null default now()
);

-- Tables transversales -------------------------------------------------
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  outlet_id uuid references outlets(id) on delete cascade,
  app app_id,
  channel text not null,                -- critique, operations, abonnement, information, coaching_ia
  type text not null,
  event_key text not null,              -- clé anti-doublon : un événement = une notification
  title text, body text, payload jsonb,
  status text not null default 'created' check (status in ('created', 'sent', 'received', 'read', 'acted', 'failed')),
  attempts int not null default 0,
  created_at timestamptz not null default now(),
  unique (user_id, event_key)
);
create table notification_preferences (
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  enabled boolean not null default true,
  quiet_from time, quiet_to time,       -- heures calmes, sauf alertes critiques
  primary key (user_id, type)
);
create table audit_log (                -- ajout seulement : aucune modification ni suppression
  id bigint generated always as identity primary key,
  actor uuid, outlet_id uuid, app app_id,
  action text not null, entity text, entity_id text,
  before_data jsonb, after_data jsonb,
  created_at timestamptz not null default now()
);
create table app_versions (             -- version minimale exigée : une version plus ancienne est bloquée à la connexion suivante
  app app_id primary key,
  min_version int not null default 1,
  latest_version int not null default 1,
  download_url text,
  apk_sha256 text,
  updated_at timestamptz not null default now()
);
create table known_signatures (         -- empreintes de signature légitimes ; une empreinte inconnue = APK modifié : synchronisation refusée
  app app_id not null,
  fingerprint text not null,
  primary key (app, fingerprint)
);
create table parser_rules (             -- règles de lecture des SMS, versionnées, téléchargées à la synchronisation
  id uuid primary key default gen_random_uuid(),
  network text not null, sender text not null, nature text not null,
  pattern text not null, required_groups text[] not null,
  version int not null default 1, active boolean not null default true,
  created_at timestamptz not null default now()
);
create table support_tickets (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id), app app_id,
  subject text, body text, status text not null default 'open',
  created_at timestamptz not null default now()
);
create table app_settings (key text primary key, value jsonb not null);   -- tolérances, délais de grâce, etc.
create table backups (id uuid primary key default gen_random_uuid(), outlet_id uuid references outlets(id), kind text, created_at timestamptz not null default now());
