import { readFileSync, writeFileSync } from "node:fs";
const strip = (f) => readFileSync(new URL("../logic/" + f, import.meta.url), "utf8").replace(/^import .*$/gm, "").replace(/^export /gm, "");
const logic = strip("money.mjs") + "\n" + strip("subscription.mjs");
const tpl = readFileSync(new URL("./admin.template.html", import.meta.url), "utf8");
writeFileSync(new URL("./admin.html", import.meta.url), tpl.replace("/*__LOGIC__*/", logic));
console.log("admin.html généré", (logic.length / 1024).toFixed(1), "Ko de logique intégrée");
