import test from "node:test";
import assert from "node:assert/strict";
import { formatFCFA, parseFCFA, floorTo100 } from "../logic/money.mjs";
import * as sub from "../logic/subscription.mjs";
import * as sms from "../logic/sms.mjs";
import * as w from "../logic/wallets.mjs";
import * as v from "../logic/verticals.mjs";

const H = 3600 * 1000, D = 24 * H;

test("argent : format et lecture", () => {
  assert.equal(formatFCFA(45000), "45 000 F"); assert.equal(formatFCFA(500), "500 F"); assert.equal(formatFCFA(1234567), "1 234 567 F"); assert.equal(formatFCFA(-2500), "-2 500 F");
  assert.equal(parseFCFA("45 000 F"), 45000); assert.equal(parseFCFA("45.000"), 45000); assert.equal(parseFCFA("1 000F"), 1000); assert.equal(parseFCFA("250 F"), 250); assert.equal(parseFCFA("abc"), null);
  assert.equal(floorTo100(4050), 4000);
});

test("abonnement : forfaits (3 mois -10 % centaine inférieure, 6 mois = 5, 12 mois = 10)", () => {
  assert.equal(sub.packagePrice(1000, 3), 2700); assert.equal(sub.packagePrice(1500, 3), 4000); assert.equal(sub.packagePrice(3000, 3), 8100);
  assert.equal(sub.packagePrice(6000, 3), 16200); assert.equal(sub.packagePrice(500, 3), 1300); assert.equal(sub.packagePrice(8000, 3), 21600);
  assert.equal(sub.packagePrice(3000, 6), 15000); assert.equal(sub.packagePrice(3000, 12), 30000); assert.equal(sub.packagePrice(20000, 12), 200000);
  assert.throws(() => sub.packagePrice(1000, 4));
});
test("abonnement : prix par application, palier, points supplémentaires", () => {
  assert.equal(sub.priceOf("bootik", "pro", 1), 3000); assert.equal(sub.priceOf("bootik", "pro", 3, 2), 8100 + 2 * 1300);
  assert.equal(sub.priceOf("kiosko", "services", 3), 4000); assert.equal(sub.priceOf("kiosko", "complet", 3), 8100); // la v1.2 indiquait 8 000 : erreur corrigée
  assert.equal(sub.priceOf("naxa_hotel", "pro", 3), 21600); assert.equal(sub.priceOf("cotiz", "essentiel", 12), 5000);
  assert.throws(() => sub.priceOf("bootik", "essentiel", 1, 1)); // l'Essentiel est limité à un point
  assert.throws(() => sub.priceOf("cotiz", "pro", 1, 1)); assert.throws(() => sub.priceOf("inconnue", "pro"));
});
test("abonnement : montée de palier et prorata", () => {
  assert.equal(sub.upgradeSupplement(1000, 1500, 15), 250); // exemple du cahier
  assert.equal(sub.upgradeSupplement(1000, 3000, 15), 1000); assert.equal(sub.upgradeSupplement(1000, 1500, 3), 100); // minimum 100 F
  assert.throws(() => sub.upgradeSupplement(3000, 1000, 10));
  assert.equal(sub.extraPointProrata(500, 15), 250); assert.equal(sub.extraPointProrata(500, 3), 100);
});
test("abonnement : mois offerts, plafond, bienvenue", () => {
  let r = sub.grantMonths({ alreadyGrantedThisYear: 2, requested: [{ type: "bienvenue", months: 1 }, { type: "parrainage", months: 1 }] });
  assert.equal(r.totalGranted, 1); assert.equal(r.granted[0].type, "bienvenue"); assert.equal(r.refused[0].reason, "plafond annuel atteint");
  r = sub.grantMonths({ requested: [{ type: "bienvenue", months: 1 }, { type: "promo", months: 1 }] });
  assert.equal(r.totalGranted, 1); assert.match(r.refused[0].reason, /non cumulable/);
  r = sub.grantMonths({ requested: [{ type: "bienvenue", months: 1 }, { type: "parrainage", months: 1 }] }); assert.equal(r.totalGranted, 2); // cumulables
  const end = Date.UTC(2026, 10, 1);
  assert.equal(sub.welcomeEligible(end, end + 47 * H), true); assert.equal(sub.welcomeEligible(end, end + 49 * H), false); assert.equal(sub.welcomeEligible(end, end - H), false);
  assert.equal(sub.referralMonthsDue(false), 0); assert.equal(sub.referralMonthsDue(true), 1);
  assert.equal(sub.includedFreeMonths(6), 1); assert.equal(sub.includedFreeMonths(12), 2); assert.equal(sub.includedFreeMonths(3), 0);
});
test("abonnement : tolérance hors connexion et blocage", () => {
  const last = Date.UTC(2026, 10, 1); const at = (d) => ({ nowMs: last + d * D + H, lastSyncMs: last, lastSeenMs: last + d * D, limitDays: 7 });
  assert.equal(sub.offlineState(at(0)).state, "ok"); assert.equal(sub.offlineState(at(3)).state, "ok"); assert.equal(sub.offlineState(at(4)).state, "warning");
  assert.equal(sub.offlineState(at(6)).state, "warning"); assert.equal(sub.offlineState(at(7)).state, "restricted");
  const at14 = (d) => ({ ...at(d), limitDays: 14 }); assert.equal(sub.offlineState(at14(13)).state, "warning"); assert.equal(sub.offlineState(at14(14)).state, "restricted");
  assert.equal(sub.offlineState({ nowMs: last, lastSyncMs: last, lastSeenMs: last + D, limitDays: 7 }).reason, "recul d'horloge");
  const due = Date.UTC(2026, 10, 1);
  assert.equal(sub.blockedState({ nowMs: due - D, dueMs: due }).state, "active"); assert.equal(sub.blockedState({ nowMs: due + 10 * D, dueMs: due }).state, "blocked_recording");
  assert.equal(sub.blockedState({ nowMs: due + 60 * D, dueMs: due }).state, "blocked_recording_stopped");
});

test("SMS : jamais d'OTP ni de PIN", () => {
  for (const t of ["Votre code OTP est 123456", "Votre PIN : 1234", "Code de vérification 4567", "Ne communiquez ce code à personne", "Your verification code is 998877", "Mot de passe temporaire : abc", "Do not share this one-time password"]) assert.equal(sms.containsSecret(t), true, t);
  for (const t of ["Depot de 10 000 F reussi. Solde 55 000 F. ID TX1001", "Transaction ID: MP2610.1234.A56"]) assert.equal(sms.containsSecret(t), false, t);
  assert.equal(sms.containsSecret(undefined), true);
  assert.equal(sms.guardIncoming("Votre OTP 123456").accepted, false);
});
test("SMS : messages sortants sans secret", () => {
  assert.equal(sms.validateOutgoingMessage("Bonjour Paul, solde OM : 45 000 F. J'ai besoin de 100 000 F de float. Merci de passer.").ok, true);
  assert.equal(sms.validateOutgoingMessage("Mon PIN est 1234").ok, false); assert.equal(sms.validateOutgoingMessage("Mon code est 123456").ok, false);
});
test("SMS : parseur par règles (règles FICTIVES), doublons, cohérence", () => {
  const r = sms.EXAMPLE_RULES_FICTIVES;
  const p = sms.parseSms({ text: "Depot de 10 000 F reussi le 01/11. Solde 55 000 F. ID TX1001", sender: "DemoMoney" }, r);
  assert.deepEqual([p.status, p.nature, p.amount, p.balanceAfter, p.txid], ["parsed", "depot", 10000, 55000, "TX1001"]);
  const q = sms.parseSms({ text: "Retrait de 2 500 F reussi. Solde 52 500 F. ID TX1002", sender: "demomoney" }, r); assert.equal(q.nature, "retrait"); assert.equal(q.amount, 2500);
  assert.equal(sms.parseSms({ text: "Votre code OTP est 123456", sender: "DemoMoney" }, r).status, "ignored");
  assert.equal(sms.parseSms({ text: "Bonjour", sender: "DemoMoney" }, r).status, "unrecognized");
  assert.equal(sms.parseSms({ text: "Depot de 1 F", sender: "Autre" }, r).status, "unknown_sender");
  assert.equal(sms.dedupeByTxid([{ txid: "A" }, { txid: "A" }, { txid: "B" }, { txid: null }, { txid: null }]).length, 4);
  assert.equal(sms.consistencyCheck({ previousBalance: 100000, delta: -10000, balanceAfter: 90000 }).status, "ok");
  assert.deepEqual(sms.consistencyCheck({ previousBalance: 100000, delta: -10000, balanceAfter: 85000 }), { status: "to_verify", gap: -5000 });
  assert.deepEqual(sms.splitPasted("SMS un\n\nSMS deux\n---\nSMS trois"), ["SMS un", "SMS deux", "SMS trois"]);
});

test("Kiosko : effets des natures d'opérations", () => {
  let wl = w.newWallet(); wl = w.applyOperation(wl, { nature: "depot", amount: 10000, commission: 150 });
  assert.deepEqual([wl.float, wl.cash, wl.commissions], [-10000, 10000, 150]);
  wl = w.applyOperation(wl, { nature: "retrait", amount: 4000 }); assert.deepEqual([wl.float, wl.cash], [-6000, 6000]);
  wl = w.applyOperation(wl, { nature: "appro_float", amount: 20000 }); assert.deepEqual([wl.float, wl.cash], [14000, -14000]);
  wl = w.applyOperation(wl, { nature: "destockage", amount: 1000 }); assert.deepEqual([wl.float, wl.cash], [13000, -13000]);
  wl = w.applyOperation(wl, { nature: "credit_appro", amount: 5000 }); assert.deepEqual([wl.float, wl.creditStock], [8000, 5000]);
  wl = w.applyOperation(wl, { nature: "credit_vente", amount: 2000, commission: 100 }); assert.deepEqual([wl.cash, wl.creditStock, wl.commissions], [-11000, 3000, 250]);
  const c = w.applyOperation(w.newWallet(), { nature: "c2c_sortie", amount: 3000, counterpartCash: 3000 }); assert.deepEqual([c.float, c.cash], [-3000, 3000]);
  assert.equal(w.applyOperation(w.newWallet(), { nature: "c2c_entree", amount: 3000 }).cash, 0); // pas de contrepartie en espèces
  assert.throws(() => w.applyOperation(w.newWallet(), { nature: "inconnue", amount: 1 })); assert.throws(() => w.applyOperation(w.newWallet(), { nature: "depot", amount: 1.5 }));
  assert.equal(w.commissionOf(100000, 15), 1500);
});
test("Kiosko : trous dans la chaîne des soldes", () => {
  const e1 = { id: "1", ts: 1000, delta: 0, balanceAfter: 100000 }, e2 = { id: "2", ts: 2000, delta: -10000, balanceAfter: 90000 }, e3 = { id: "3", ts: 3000, delta: -5000, balanceAfter: 70000 };
  const far = { nowMs: 3000 + 3600e3 };
  assert.deepEqual(w.detectGaps([e1, e2], far), []);
  const g = w.detectGaps([e3, e1, e2], far); // arrivés dans le désordre
  assert.equal(g.length, 1); assert.equal(g[0].diff, -15000); assert.equal(g[0].status, "alert"); assert.match(g[0].hint, /float qui baisse/);
  assert.equal(w.detectGaps([e1, e2, e3], { nowMs: 3000 + 60e3 })[0].status, "pending"); // on attend quelques minutes
  assert.equal(w.detectGaps([e1, e2, e3], { ...far, alreadyReported: new Set(["2->3"]) }).length, 0); // une alerte par trou
  assert.equal(w.matchesManual({ nature: "depot", amount: 5000, ts: 1000 }, { nature: "depot", amount: 5000, ts: 1000 + 10 * 60e3 }), true);
  assert.equal(w.matchesManual({ nature: "depot", amount: 5000, ts: 1000 }, { nature: "depot", amount: 6000, ts: 1000 }), false);
  let s = { armedOff: false }; let r = w.thresholdAlert(s, 40000, 50000); assert.equal(r.notify, true);
  r = w.thresholdAlert(r.state, 30000, 50000); assert.equal(r.notify, false); // une seule notification
  r = w.thresholdAlert(r.state, 80000, 50000); assert.equal(r.notify, false);
  r = w.thresholdAlert(r.state, 20000, 50000); assert.equal(r.notify, true); // réarmée puis franchie à nouveau
  assert.equal(w.amountToRequest(30000, 100000), 70000); assert.equal(w.amountToRequest(120000, 100000), 0);
});

test("Bootik : dépôt de gaz", () => {
  let st = v.gasReceive({}, "A", "12.5", { full: 10, empty: 0 });
  st = v.gasExchange(st, "A", "12.5", 2); assert.deepEqual(st["A|12.5"], { full: 8, empty: 2, defective: 0 });
  assert.throws(() => v.gasExchange(st, "A", "12.5", 20));
  const r = v.gasSaleWithDeposit(st, {}, { clientId: "c1", brand: "A", size: "12.5", gasPrice: 6000, depositPerBottle: 10000 });
  assert.equal(r.amountDue, 16000); assert.equal(r.stock["A|12.5"].full, 7); assert.equal(r.deposits.c1.held, 10000);
  const back = v.gasReturnBottle(r.stock, r.deposits, { clientId: "c1", brand: "A", size: "12.5", depositPerBottle: 10000 });
  assert.equal(back.refund, 10000); assert.equal(back.stock["A|12.5"].empty, 3); assert.equal(back.deposits.c1.held, 0);
  assert.throws(() => v.gasReturnBottle(back.stock, back.deposits, { clientId: "c1", brand: "A", size: "12.5", depositPerBottle: 10000 }));
  assert.deepEqual(v.gasInventoryGap({ "A|12.5": { full: 7, empty: 3 } }, { "A|12.5": { full: 6, empty: 3 } }), [{ key: "A|12.5", fullGap: -1, emptyGap: 0 }]);
});
test("Zipple : recettes et rendement", () => {
  const recipe = { riz: 200, poulet: 150 };
  const ok = v.consumeIngredients({ riz: 1000, poulet: 600 }, recipe, 3); assert.equal(ok.ok, true); assert.deepEqual(ok.stock, { riz: 400, poulet: 150 });
  const ko = v.consumeIngredients({ riz: 1000, poulet: 600 }, recipe, 5); assert.equal(ko.ok, false); assert.equal(ko.missing[0].ing, "poulet");
  assert.equal(v.dishCost(recipe, { riz: 1, poulet: 4 }), 800); assert.equal(v.dishMarginPerMille(2000, 800), 600); assert.equal(v.yieldPerMille(10000, 6500), 650);
});
test("CotiZ : cotisations, pénalités, tirage vérifiable, prêts", () => {
  assert.equal(v.contributionDue(2, 5000), 10000);
  assert.equal(v.penaltyOf({ lateDays: 3, absent: true, missedAmount: 10000 }, { latePerDay: 500, absence: 2000, missedPercentPerMille: 50 }), 4000);
  const P = ["A", "B", "C", "D", "E"]; const o1 = v.drawOrder(P, "graine-test-1");
  assert.deepEqual(o1, ["D", "B", "A", "E", "C"]); assert.deepEqual(v.drawOrder(["E", "C", "A", "D", "B"], "graine-test-1"), o1); // rejouable, indépendant de l'ordre d'entrée
  assert.deepEqual([...o1].sort(), P); assert.notDeepEqual(v.drawOrder(P, "graine-test-2"), o1);
  const s = v.loanSchedule({ principal: 100000, ratePerMille: 30, periods: 4, method: "simple" });
  assert.equal(s.totalInterest, 12000); assert.equal(s.totalPaid, 112000); assert.equal(s.rows.at(-1).balanceAfter, 0); assert.equal(s.rows.reduce((a, r) => a + r.principal, 0), 100000);
  const d = v.loanSchedule({ principal: 100000, ratePerMille: 30, periods: 4, method: "degressif" });
  assert.equal(d.rows[0].total, 26903); assert.equal(d.rows.reduce((a, r) => a + r.principal, 0), 100000); assert.equal(d.rows.at(-1).balanceAfter, 0);
  assert.equal(v.loanSchedule({ principal: 90000, ratePerMille: 0, periods: 3, method: "degressif" }).totalInterest, 0);
  assert.equal(v.savingsProgressPerMille(25000, 100000), 250); assert.equal(v.savingsProgressPerMille(150000, 100000), 1000);
});
test("Loyable : locatif", () => {
  assert.equal(v.rentNet({ rentsCollected: 500000, charges: 50000, works: 30000 }), 420000);
  assert.deepEqual([0, 1, 7, 8, 15, 16, 40].map(v.reminderLevel), [0, 1, 1, 2, 2, 3, 3]);
  assert.equal(v.receiptNumber(2026, 123), "Q-2026-000123"); assert.equal(v.proposeRent(100000, 50), 105000); assert.equal(v.proposeRent(85000, 30), 87600);
  assert.equal(v.occupancyPerMille(8, 10), 800);
});
test("NAXA Hotel : tarifs, chevauchements, conflits hors connexion, compte du séjour, indicateurs", () => {
  const rates = { base: { double: 25000, suite: 50000 }, seasons: [{ from: "2026-12-15", to: "2027-01-05", multPerMille: 1300 }], weekend: { days: [5, 6], multPerMille: 1100 }, company: { ACME: 100 }, los: [{ minNights: 7, discountPerMille: 150 }] };
  assert.equal(v.nightsBetween("2026-11-01", "2026-11-04"), 3); assert.deepEqual(v.nightDates("2026-11-01", "2026-11-03"), ["2026-11-01", "2026-11-02"]);
  assert.equal(v.nightRate(rates, "double", "2026-11-03"), 25000);        // mardi
  assert.equal(v.nightRate(rates, "double", "2026-11-06"), 27500);        // vendredi
  assert.equal(v.nightRate(rates, "double", "2026-12-20"), 32500);        // dimanche, haute saison
  assert.equal(v.nightRate(rates, "double", "2026-12-25"), 35750);        // vendredi, haute saison
  assert.equal(v.nightRate(rates, "double", "2026-11-03", { companyId: "ACME" }), 22500);
  assert.equal(v.nightRate(rates, "double", "2026-11-03", { totalNights: 7 }), 21250);
  assert.equal(v.nightRate(rates, "double", "2026-11-03", { companyId: "ACME", totalNights: 7 }), 21250); // meilleure remise, sans cumul
  assert.equal(v.stayPrice(rates, "double", "2026-11-02", "2026-11-05").total, 75000); assert.equal(v.stayPrice(rates, "double", "2026-11-05", "2026-11-08").total, 80000);
  assert.throws(() => v.nightRate(rates, "inconnu", "2026-11-03"));
  const a = { roomId: "r1", checkIn: "2026-10-01", checkOut: "2026-10-05" };
  assert.equal(v.overlaps(a, { checkIn: "2026-10-05", checkOut: "2026-10-08" }), false); assert.equal(v.overlaps(a, { checkIn: "2026-10-04", checkOut: "2026-10-06" }), true);
  const res = v.resolveConflicts([
    { id: "R2", roomId: "r1", checkIn: "2026-10-04", checkOut: "2026-10-06", serverReceivedAt: 2000 },
    { id: "R1", roomId: "r1", checkIn: "2026-10-01", checkOut: "2026-10-05", serverReceivedAt: 1000 },
    { id: "R3", roomId: "r2", checkIn: "2026-10-04", checkOut: "2026-10-06", serverReceivedAt: 1500 },
    { id: "R4", roomId: "r1", checkIn: "2026-10-05", checkOut: "2026-10-07", serverReceivedAt: 3000 },
    { id: "R5", roomId: "r1", checkIn: "2026-10-02", checkOut: "2026-10-03", serverReceivedAt: 500, status: "cancelled" }]);
  const by = Object.fromEntries(res.map((r) => [r.id, r])); assert.equal(by.R1.status, "confirmed"); assert.equal(by.R2.status, "to_replace"); assert.equal(by.R2.conflictWith, "R1");
  assert.equal(by.R3.status, "confirmed"); assert.equal(by.R4.status, "confirmed"); assert.equal(by.R5.status, "cancelled");
  const f = v.folioTotals([{ amount: 25000, qty: 3 }, { amount: 5000, qty: 2 }], { vatBasisPoints: 1000, stayTaxPerNightPerGuest: 500, nights: 3, guests: 2 });
  assert.deepEqual(f, { subtotal: 85000, vat: 8500, stayTax: 3000, total: 96500 }); assert.equal(v.folioBalance(96500, [{ amount: 50000 }]), 46500);
  assert.deepEqual(v.hotelKpis({ roomRevenue: 3000000, nightsSold: 120, rooms: 10, daysInPeriod: 30 }), { available: 300, occupancyPerMille: 400, adr: 25000, revpar: 10000 });
  assert.deepEqual(v.hotelKpis({ roomRevenue: 3000000, nightsSold: 120, rooms: 10, daysInPeriod: 30, outOfServiceNights: 30 }), { available: 270, occupancyPerMille: 444, adr: 25000, revpar: 11111 });
});
