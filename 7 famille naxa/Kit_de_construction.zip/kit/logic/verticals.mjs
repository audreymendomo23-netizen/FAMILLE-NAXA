import { createHmac } from "node:crypto";
import { toInt } from "./money.mjs";

// =====================================================================  BOOTIK : DÉPÔT DE GAZ
export const gasKey = (brand, size) => `${brand}|${size}`;
export function gasEnsure(stock, brand, size) { const k = gasKey(brand, size); return { ...stock, [k]: stock[k] ?? { full: 0, empty: 0, defective: 0 } }; }
export function gasReceive(stock, brand, size, { full = 0, empty = 0 }) { const s = gasEnsure(stock, brand, size); const k = gasKey(brand, size); return { ...s, [k]: { ...s[k], full: s[k].full + full, empty: s[k].empty + empty } }; }
// Échange : le client rend une vide et reçoit une pleine (vide +1, pleine -1).
export function gasExchange(stock, brand, size, qty = 1) {
  const k = gasKey(brand, size); const cur = stock[k]; if (!cur || cur.full < qty) throw new Error("stock de bouteilles pleines insuffisant");
  return { ...stock, [k]: { ...cur, full: cur.full - qty, empty: cur.empty + qty } };
}
// Vente avec consigne : le client n'a pas de vide ; il reçoit une pleine et laisse une consigne.
export function gasSaleWithDeposit(stock, deposits, { clientId, brand, size, qty = 1, gasPrice, depositPerBottle }) {
  const k = gasKey(brand, size); const cur = stock[k]; if (!cur || cur.full < qty) throw new Error("stock de bouteilles pleines insuffisant");
  const dep = deposits[clientId] ?? { bottles: {}, held: 0 };
  const nd = { bottles: { ...dep.bottles, [k]: (dep.bottles[k] ?? 0) + qty }, held: dep.held + qty * depositPerBottle };
  return { stock: { ...stock, [k]: { ...cur, full: cur.full - qty } }, deposits: { ...deposits, [clientId]: nd }, amountDue: qty * (gasPrice + depositPerBottle) };
}
// Retour d'une bouteille : la consigne est soldée, la vide entre en stock, la consigne est restituée.
export function gasReturnBottle(stock, deposits, { clientId, brand, size, qty = 1, depositPerBottle }) {
  const k = gasKey(brand, size); const dep = deposits[clientId]; if (!dep || (dep.bottles[k] ?? 0) < qty) throw new Error("aucune consigne de cette bouteille pour ce client");
  const cur = stock[k] ?? { full: 0, empty: 0, defective: 0 };
  return { stock: { ...stock, [k]: { ...cur, empty: cur.empty + qty } }, deposits: { ...deposits, [clientId]: { bottles: { ...dep.bottles, [k]: dep.bottles[k] - qty }, held: dep.held - qty * depositPerBottle } }, refund: qty * depositPerBottle };
}
export function gasInventoryGap(theoretical, counted) {
  const out = []; for (const k of new Set([...Object.keys(theoretical), ...Object.keys(counted)])) {
    const t = theoretical[k] ?? { full: 0, empty: 0 }, c = counted[k] ?? { full: 0, empty: 0 };
    if (t.full !== c.full || t.empty !== c.empty) out.push({ key: k, fullGap: c.full - t.full, emptyGap: c.empty - t.empty });
  } return out;
}

// =====================================================================  ZIPPLE : RECETTES ET RENDEMENT
export function consumeIngredients(stock, recipe, portions) {
  const next = { ...stock }; const missing = [];
  for (const [ing, qtyPerPortion] of Object.entries(recipe)) {
    const need = qtyPerPortion * portions; if ((next[ing] ?? 0) < need) missing.push({ ing, need, have: next[ing] ?? 0 }); else next[ing] -= need;
  }
  return missing.length ? { ok: false, missing, stock } : { ok: true, stock: next };
}
export const dishCost = (recipe, unitCosts) => toInt(Object.entries(recipe).reduce((s, [ing, q]) => s + q * (unitCosts[ing] ?? 0), 0));
export const dishMarginPerMille = (price, cost) => (price <= 0 ? 0 : Math.round(((price - cost) * 1000) / price));
// Rendement du braiseur : poids vendu / poids acheté, en pour mille (entier).
export const yieldPerMille = (boughtGrams, soldGrams) => (boughtGrams <= 0 ? 0 : Math.round((soldGrams * 1000) / boughtGrams));

// =====================================================================  COTIZ : TONTINE
// Cotisation attendue par séance : parts x montant par part.
export const contributionDue = (parts, amountPerPart) => parts * amountPerPart;
// Pénalités : barème réglé par le groupe. { latePerDay, absence, missedPercentPerMille }
export function penaltyOf({ lateDays = 0, absent = false, missedAmount = 0 }, bareme) {
  return toInt((bareme.latePerDay ?? 0) * lateDays + (absent ? bareme.absence ?? 0 : 0) + (missedAmount * (bareme.missedPercentPerMille ?? 0)) / 1000);
}
// Tirage au sort vérifiable : l'ordre est entièrement déterminé par (participants, seed). Le groupe conserve la graine dans le journal ;
// n'importe qui peut rejouer le tirage et obtenir le même ordre. Flux pseudo-aléatoire = HMAC-SHA256(seed, compteur), tirage sans biais.
export function drawOrder(participants, seed) {
  const arr = [...participants].sort(); let counter = 0;
  const nextInt = (maxExclusive) => { // rejection sampling sur 32 bits
    const limit = Math.floor(0x100000000 / maxExclusive) * maxExclusive;
    for (;;) { const h = createHmac("sha256", seed).update(String(counter++)).digest(); const v = h.readUInt32BE(0); if (v < limit) return v % maxExclusive; }
  };
  for (let i = arr.length - 1; i > 0; i--) { const j = nextInt(i + 1); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}
// Échéancier d'un prêt interne. method : "simple" (intérêt fixe sur le capital initial, par période) ou "degressif" (annuité constante).
// ratePerMille : taux PAR PÉRIODE en pour mille (30 = 3 %). Le dernier versement absorbe les arrondis. Taux et légalité : à faire valider.
export function loanSchedule({ principal, ratePerMille, periods, method = "simple" }) {
  if (periods < 1) throw new Error("durée invalide");
  const rows = []; let remaining = principal;
  if (method === "simple") {
    const interestEach = Math.round((principal * ratePerMille) / 1000); const principalEach = Math.floor(principal / periods);
    for (let i = 1; i <= periods; i++) { const pr = i === periods ? remaining : principalEach; rows.push({ n: i, principal: pr, interest: interestEach, total: pr + interestEach, balanceAfter: remaining - pr }); remaining -= pr; }
  } else {
    const r = ratePerMille / 1000; const pay = r === 0 ? principal / periods : (principal * r) / (1 - Math.pow(1 + r, -periods));
    for (let i = 1; i <= periods; i++) {
      const interest = Math.round(remaining * r); let total = Math.round(pay); let pr = total - interest;
      if (i === periods) { pr = remaining; total = pr + interest; }
      rows.push({ n: i, principal: pr, interest, total, balanceAfter: remaining - pr }); remaining -= pr;
    }
  }
  return { rows, totalInterest: rows.reduce((s, x) => s + x.interest, 0), totalPaid: rows.reduce((s, x) => s + x.total, 0) };
}
export const savingsProgressPerMille = (saved, goal) => (goal <= 0 ? 0 : Math.min(1000, Math.round((saved * 1000) / goal)));

// =====================================================================  LOYABLE : LOCATIF
export const rentNet = ({ rentsCollected, charges = 0, works = 0 }) => rentsCollected - charges - works;
// Niveau de relance : 1 rappel amical (1 à 7 jours), 2 relance (8 à 15), 3 mise en demeure à valider par le bailleur (16 et plus). [P]
export const reminderLevel = (daysLate) => (daysLate <= 0 ? 0 : daysLate <= 7 ? 1 : daysLate <= 15 ? 2 : 3);
export const receiptNumber = (year, seq) => `Q-${year}-${String(seq).padStart(6, "0")}`;
// Proposition de révision de loyer (le bailleur valide) : pourcentage en pour mille, arrondi à la centaine supérieure.
export const proposeRent = (rent, pctPerMille) => Math.ceil((rent * (1000 + pctPerMille)) / 1000 / 100) * 100;
export const occupancyPerMille = (occupied, total) => (total <= 0 ? 0 : Math.round((occupied * 1000) / total));

// =====================================================================  NAXA HOTEL
const DAY = 86400000;
export const dayMs = (iso) => Date.parse(iso + "T00:00:00Z");
export const nightsBetween = (checkIn, checkOut) => Math.round((dayMs(checkOut) - dayMs(checkIn)) / DAY);
export const nightDates = (checkIn, checkOut) => Array.from({ length: nightsBetween(checkIn, checkOut) }, (_, i) => new Date(dayMs(checkIn) + i * DAY).toISOString().slice(0, 10));
// Tarif d'une nuit : base du type de chambre x coefficient de saison x coefficient week-end, puis remise entreprise et remise longue durée (pour mille).
// rates = { base: {double: 25000}, seasons: [{from, to, multPerMille}], weekend: {days: [5,6], multPerMille}, company: {id: discountPerMille}, los: [{minNights, discountPerMille}] }
export function nightRate(rates, roomType, dateIso, { companyId = null, totalNights = 1 } = {}) {
  let v = rates.base[roomType]; if (v == null) throw new Error("type de chambre inconnu");
  const season = (rates.seasons ?? []).find((s) => dateIso >= s.from && dateIso <= s.to); if (season) v = Math.round((v * season.multPerMille) / 1000);
  const dow = new Date(dayMs(dateIso)).getUTCDay(); if (rates.weekend?.days.includes(dow)) v = Math.round((v * rates.weekend.multPerMille) / 1000);
  const losDisc = (rates.los ?? []).filter((l) => totalNights >= l.minNights).reduce((m, l) => Math.max(m, l.discountPerMille), 0);
  const compDisc = companyId ? rates.company?.[companyId] ?? 0 : 0;
  return Math.round((v * (1000 - Math.max(losDisc, compDisc))) / 1000); // la meilleure des deux remises s'applique, sans cumul
}
export function stayPrice(rates, roomType, checkIn, checkOut, opts = {}) {
  const dates = nightDates(checkIn, checkOut); const nights = dates.length;
  const perNight = dates.map((d) => ({ date: d, rate: nightRate(rates, roomType, d, { ...opts, totalNights: nights }) }));
  return { nights, perNight, total: perNight.reduce((s, n) => s + n.rate, 0) };
}
// Intervalles semi-ouverts [arrivée, départ) : un départ le 10 et une arrivée le 10 ne se chevauchent pas.
export const overlaps = (a, b) => a.checkIn < b.checkOut && b.checkIn < a.checkOut;
// Conflits de réservation hors connexion : par chambre, la première réservation enregistrée par le serveur gagne ;
// les autres qui la chevauchent deviennent « to_replace » (à replacer) avec alerte au manager.
export function resolveConflicts(reservations) {
  const byRoom = {}; for (const r of reservations) (byRoom[r.roomId] ??= []).push(r);
  const result = [];
  for (const list of Object.values(byRoom)) {
    const sorted = [...list].sort((a, b) => a.serverReceivedAt - b.serverReceivedAt || String(a.id).localeCompare(String(b.id)));
    const accepted = [];
    for (const r of sorted) {
      if (r.status === "cancelled") { result.push({ ...r }); continue; }
      const clash = accepted.find((a) => overlaps(a, r));
      if (clash) result.push({ ...r, status: "to_replace", conflictWith: clash.id }); else { accepted.push(r); result.push({ ...r, status: "confirmed" }); }
    }
  }
  return result;
}
// Compte du séjour : TVA en points de base (1000 = 10 %, taux réel à confirmer) sur le sous-total, taxe de séjour par nuit et par personne (montant fixe).
export function folioTotals(lines, { vatBasisPoints = 0, stayTaxPerNightPerGuest = 0, nights = 0, guests = 1 } = {}) {
  const subtotal = lines.reduce((s, l) => s + l.amount * (l.qty ?? 1), 0);
  const vat = Math.round((subtotal * vatBasisPoints) / 10000); const stayTax = stayTaxPerNightPerGuest * nights * guests;
  return { subtotal, vat, stayTax, total: subtotal + vat + stayTax };
}
export const folioBalance = (total, payments) => total - payments.reduce((s, p) => s + p.amount, 0);
// Indicateurs : occupation, prix moyen de la chambre vendue (ADR), revenu par chambre disponible (RevPAR). Tous les montants en entiers.
export function hotelKpis({ roomRevenue, nightsSold, rooms, daysInPeriod, outOfServiceNights = 0 }) {
  const available = rooms * daysInPeriod - outOfServiceNights;
  return { available, occupancyPerMille: available <= 0 ? 0 : Math.round((nightsSold * 1000) / available), adr: nightsSold <= 0 ? 0 : Math.round(roomRevenue / nightsSold), revpar: available <= 0 ? 0 : Math.round(roomRevenue / available) };
}
