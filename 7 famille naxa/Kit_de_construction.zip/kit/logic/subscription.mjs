import { floorTo100, toInt } from "./money.mjs";
// Grilles de prix mensuels (francs CFA). Source : cahiers des charges 01 à 07 (tous marqués [P] : à tester sur le terrain).
export const APPS = {
  kiosko:        { name: "Kiosko",        tiers: { essentiel: 1000, services: 1500, complet: 3000 }, extraPoint: { price: 500, tiers: ["services", "complet"] }, singlePointTiers: ["essentiel"], offlineDays: { essentiel: 7, services: 7, complet: 14 } },
  bootik:        { name: "Bootik",        tiers: { essentiel: 1000, pro: 3000, reseau: 6000 },       extraPoint: { price: 500, tiers: ["pro"] },  singlePointTiers: ["essentiel"], offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
  zipple:        { name: "Zipple",        tiers: { essentiel: 1000, pro: 3000, reseau: 6000 },       extraPoint: { price: 500, tiers: ["pro"] },  singlePointTiers: ["essentiel"], offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
  naxa_services: { name: "NAXA Services", tiers: { essentiel: 1000, pro: 3000, reseau: 6000 },       extraPoint: { price: 500, tiers: ["pro"] },  singlePointTiers: ["essentiel"], offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
  cotiz:         { name: "CotiZ",         tiers: { essentiel: 500, pro: 1500, reseau: 3000 },        extraPoint: null,                             singlePointTiers: [],            offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
  loyable:       { name: "Loyable",       tiers: { essentiel: 1000, pro: 3000, reseau: 6000 },       extraPoint: null,                             singlePointTiers: [],            offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
  naxa_hotel:    { name: "NAXA Hotel",    tiers: { essentiel: 3000, pro: 8000, reseau: 20000 },      extraPoint: { price: 2000, tiers: ["pro"] }, singlePointTiers: ["essentiel"], offlineDays: { essentiel: 7, pro: 7, reseau: 14 } },
};
export const DURATIONS = [1, 3, 6, 12];

// Prix d'un forfait pour un prix mensuel donné : 3 mois = -10 % arrondi à la centaine inférieure ; 6 mois = 5 payés ; 12 mois = 10 payés.
export function packagePrice(monthly, months) {
  switch (months) {
    case 1: return monthly;
    case 3: return floorTo100(monthly * 3 * 0.9);
    case 6: return monthly * 5;
    case 12: return monthly * 10;
    default: throw new Error("durée inconnue : " + months);
  }
}
// Mois réellement offerts par le forfait (6 mois -> 1 offert ; 12 mois -> 2 offerts).
export const includedFreeMonths = (months) => (months === 6 ? 1 : months === 12 ? 2 : 0);

export function priceOf(app, tier, months = 1, extraPoints = 0) {
  const a = APPS[app]; if (!a || !(tier in a.tiers)) throw new Error("application ou palier inconnu");
  let total = packagePrice(a.tiers[tier], months);
  if (extraPoints > 0) {
    if (!a.extraPoint || !a.extraPoint.tiers.includes(tier)) throw new Error("points supplémentaires non permis pour ce palier");
    total += extraPoints * packagePrice(a.extraPoint.price, months);
  }
  return total;
}
// Montée de palier immédiate : (différence de prix mensuel) x jours restants / 30, minimum 100 F, échéance inchangée.
// Calculé sur la valeur mensuelle du palier, pas sur le prix réduit du forfait. Arrondi au franc le plus proche (à confirmer).
export function upgradeSupplement(oldMonthly, newMonthly, daysLeft) {
  if (newMonthly <= oldMonthly) throw new Error("ce n'est pas une montée de palier");
  if (daysLeft < 0) throw new Error("jours restants invalides");
  return Math.max(100, toInt(((newMonthly - oldMonthly) * daysLeft) / 30));
}
// Ajout d'un point en cours de période : prix mensuel du point x jours restants / 30 (même arrondi). Minimum 100 F.
export const extraPointProrata = (monthlyPointPrice, daysLeft) => Math.max(100, toInt((monthlyPointPrice * daysLeft) / 30));

// Mois offerts : plafond de 3 mois par an hors mois inclus dans les forfaits 6 et 12 mois.
// Le code promo n'est pas cumulable avec la bienvenue (la bienvenue gagne si les deux sont demandés).
export function grantMonths({ alreadyGrantedThisYear = 0, requested = [] }) {
  const CAP = 3; let remaining = Math.max(0, CAP - alreadyGrantedThisYear); const granted = []; let refused = [];
  const hasWelcome = requested.some((r) => r.type === "bienvenue");
  for (const r of requested) {
    if (r.type === "promo" && hasWelcome) { refused.push({ ...r, reason: "promo non cumulable avec bienvenue" }); continue; }
    const g = Math.min(remaining, r.months); if (g > 0) granted.push({ type: r.type, months: g });
    if (g < r.months) refused.push({ ...r, months: r.months - g, reason: "plafond annuel atteint" });
    remaining -= g;
  }
  return { granted, refused, totalGranted: granted.reduce((s, g) => s + g.months, 0) };
}
// Offre de bienvenue : paiement dans les 48 h après la fin de la période accordée.
export const welcomeEligible = (periodEndMs, paidAtMs) => paidAtMs >= periodEndMs - 0 && paidAtMs - periodEndMs <= 48 * 3600 * 1000;
// Parrainage : mois accordé après le premier paiement réel du filleul.
export const referralMonthsDue = (refereeHasRealPayment) => (refereeHasRealPayment ? 1 : 0);

// Tolérance hors connexion. days = jours entiers depuis la dernière synchronisation (heure du serveur mémorisée).
export function offlineState({ nowMs, lastSyncMs, lastSeenMs, limitDays }) {
  if (lastSeenMs != null && nowMs < lastSeenMs) return { state: "restricted", reason: "recul d'horloge" };
  const days = Math.floor((nowMs - lastSyncMs) / 86400000);
  if (days >= limitDays) return { state: "restricted", reason: "tolérance dépassée", days };
  if (days >= 4) return { state: "warning", days, deadlineMs: lastSyncMs + limitDays * 86400000 };
  return { state: "ok", days };
}
// Blocage après échéance : l'enregistrement local des SMS s'arrête après 60 jours.
export function blockedState({ nowMs, dueMs }) {
  if (nowMs <= dueMs) return { state: "active" };
  const days = Math.floor((nowMs - dueMs) / 86400000);
  return { state: days >= 60 ? "blocked_recording_stopped" : "blocked_recording", days };
}
