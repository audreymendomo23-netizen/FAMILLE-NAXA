// Montants en francs CFA : entiers, jamais de décimales.
export const toInt = (n) => { if (!Number.isFinite(n)) throw new Error("montant invalide"); return Math.round(n); };
export function formatFCFA(n) {
  const v = toInt(n); const s = Math.abs(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return (v < 0 ? "-" : "") + s + " F";
}
// Lit « 45 000 F », « 45.000 », « 45,000 FCFA », « 1 000F » -> 45000 (entier) ; sinon null.
export function parseFCFA(text) {
  if (typeof text !== "string") return null;
  const m = text.replace(/\u00a0|\u202f/g, " ").match(/(-?\d{1,3}(?:[ .,]\d{3})+|-?\d+)\s*(?:F\s*CFA|FCFA|XAF|F)?/i);
  if (!m) return null;
  return parseInt(m[1].replace(/[ .,]/g, ""), 10);
}
export const floorTo100 = (n) => Math.floor(n / 100) * 100;
