import { parseFCFA } from "./money.mjs";

// ------------------------------------------------------------------ SÉCURITÉ : OTP et PIN
// Règle absolue : un SMS qui contient ou annonce un OTP ou un PIN n'est ni lu, ni stocké, ni transmis, ni affiché.
// Le filtre est volontairement prudent : en cas de doute, le SMS est ignoré (mieux vaut ignorer un SMS que stocker un code).
const SECRET_PATTERNS = [
  /\botp\b/i,
  /\bpin\b/i,
  /\bcode\s+(?:secret|confidentiel|personnel)\b/i,
  /\bcode\s+(?:de\s+)?(?:v[eé]rification|confirmation|s[eé]curit[eé]|validation|connexion|activation|retrait)\b/i,
  /\b(?:verification|confirmation|security|one[- ]time|login|access)\s+code\b/i,
  /\bone[- ]time\s+(?:password|passcode|pin)\b/i,
  /\bmot\s+de\s+passe\b/i,
  /\bpassword\b/i,
  /\bpasscode\b/i,
  /\bne\s+(?:le\s+)?(?:communiquez|partagez|divulguez)\b/i,
  /\bdo\s+not\s+share\b/i,
];
export function containsSecret(text) {
  if (typeof text !== "string") return true; // type inattendu : on refuse
  return SECRET_PATTERNS.some((re) => re.test(text));
}
// À utiliser avant tout enregistrement, journal ou synchronisation.
export function guardIncoming(text) {
  return containsSecret(text) ? { accepted: false, reason: "secret_detected" } : { accepted: true, text };
}
// Message WhatsApp sortant : refuse tout message qui contient un PIN ou un OTP, ou une suite de 4 à 8 chiffres isolée
// précédée d'un mot évoquant un code.
export function validateOutgoingMessage(text) {
  if (containsSecret(text)) return { ok: false, reason: "secret_detected" };
  if (/\bcode\b[^\n]{0,15}\b\d{4,8}\b/i.test(text)) return { ok: false, reason: "code_like_number" };
  return { ok: true };
}

// ------------------------------------------------------------------ PARSEUR PAR RÈGLES (règles = données)
// Une règle : { id, version, network, sender, nature, pattern (regex avec groupes nommés), requiredGroups }
// Groupes reconnus : amount, fee, balance, txid, date, time, counterparty.
// ATTENTION : les règles ci-dessous sont des EXEMPLES FICTIFS pour tester le moteur. Elles ne reproduisent PAS les formats
// réels d'Orange Money, MTN MoMo ou Wave. Les vraies règles doivent être écrites sur le corpus réel de SMS collecté (cahier, 6.10).
export const EXAMPLE_RULES_FICTIVES = [
  { id: "demo-depot", version: 1, network: "demo", sender: "DemoMoney", nature: "depot",
    pattern: "Depot de (?<amount>[\\d ., ]+) F reussi.*?Solde (?<balance>[\\d ., ]+) F.*?ID (?<txid>[A-Z0-9]+)", requiredGroups: ["amount", "balance", "txid"] },
  { id: "demo-retrait", version: 1, network: "demo", sender: "DemoMoney", nature: "retrait",
    pattern: "Retrait de (?<amount>[\\d ., ]+) F reussi.*?Solde (?<balance>[\\d ., ]+) F.*?ID (?<txid>[A-Z0-9]+)", requiredGroups: ["amount", "balance", "txid"] },
];
export function parseSms({ text, sender }, rules) {
  const g = guardIncoming(text);
  if (!g.accepted) return { status: "ignored", reason: g.reason }; // rien n'est conservé
  const candidates = rules.filter((r) => r.sender.toLowerCase() === String(sender).toLowerCase());
  if (candidates.length === 0) return { status: "unknown_sender" };
  for (const r of candidates) {
    const m = new RegExp(r.pattern, "is").exec(text);
    if (!m || !m.groups) continue;
    if (!r.requiredGroups.every((k) => m.groups[k] != null && m.groups[k] !== "")) continue;
    const amount = parseFCFA(m.groups.amount); const balance = m.groups.balance ? parseFCFA(m.groups.balance) : null;
    const fee = m.groups.fee ? parseFCFA(m.groups.fee) : 0;
    if (amount == null) continue;
    return { status: "parsed", ruleId: r.id, ruleVersion: r.version, network: r.network, nature: r.nature, amount, fee, balanceAfter: balance, txid: m.groups.txid ?? null };
  }
  return { status: "unrecognized" }; // va dans la file « À classer »
}
// Contrôle de cohérence : ancien solde ± effet = nouveau solde, sinon « à vérifier ».
export function consistencyCheck({ previousBalance, delta, balanceAfter }) {
  if (previousBalance == null || balanceAfter == null) return { status: "unknown" };
  return previousBalance + delta === balanceAfter ? { status: "ok" } : { status: "to_verify", gap: balanceAfter - (previousBalance + delta) };
}
// Dédoublonnage par identifiant de transaction (même ID = une seule opération).
export function dedupeByTxid(operations, seen = new Set()) {
  const out = [];
  for (const op of operations) {
    if (op.txid && seen.has(op.txid)) continue;
    if (op.txid) seen.add(op.txid);
    out.push(op);
  }
  return out;
}
// Séparation d'un texte collé contenant plusieurs SMS : les messages sont séparés par une ligne vide ou une ligne de tirets.
export function splitPasted(text) {
  return text.split(/\n\s*\n|\n-{3,}\n/).map((s) => s.trim()).filter(Boolean);
}
