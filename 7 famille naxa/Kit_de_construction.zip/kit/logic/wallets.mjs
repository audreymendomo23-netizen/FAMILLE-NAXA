// Moteur de soldes de Kiosko (cahier 01, section 2.4 de la v1.2).
// Définitions de « déstockage » et de « C2C » : PROPOSÉES, à faire confirmer par la porteuse du projet.
export const NATURES = {
  depot:         { float: -1, cash: +1 },            // le client dépose : le gérant envoie la monnaie électronique
  retrait:       { float: +1, cash: -1 },
  appro_float:   { float: +1, cash: -1 },            // achat de float au livreur, superviseur ou agent
  destockage:    { float: -1, cash: +1 },            // retour ou revente de float
  c2c_sortie:    { float: -1, cash: +1, optionalCash: true },  // échange de float de call box à call box
  c2c_entree:    { float: +1, cash: -1, optionalCash: true },
  credit_appro:  { float: -1, creditStock: +1 },     // achat de crédit / Good Deal
  credit_vente:  { cash: +1, creditStock: -1 },      // vente : marge = commission
};
export const newWallet = () => ({ float: 0, cash: 0, creditStock: 0, commissions: 0 });

// Applique une opération et renvoie le nouveau portefeuille (sans modifier l'ancien).
export function applyOperation(wallet, op) {
  const rule = NATURES[op.nature]; if (!rule) throw new Error("nature inconnue : " + op.nature);
  if (!Number.isInteger(op.amount) || op.amount < 0) throw new Error("montant invalide");
  const w = { ...wallet };
  if (rule.float) w.float += rule.float * op.amount;
  if (rule.cash && (!rule.optionalCash || op.counterpartCash != null)) w.cash += rule.cash * (rule.optionalCash ? op.counterpartCash : op.amount);
  if (rule.creditStock) w.creditStock += rule.creditStock * op.amount;
  if (op.commission) w.commissions += op.commission;
  return w;
}
// Effet sur le float seul (utile pour la détection de trous).
export const floatDelta = (nature, amount) => (NATURES[nature]?.float ?? 0) * amount;

// Commission calculée d'après le taux réglé (taux en pour mille pour rester entier : 15 = 1,5 %).
export const commissionOf = (amount, ratePerMille) => Math.round((amount * ratePerMille) / 1000);

// Alerte de trou dans la chaîne des soldes (6.11.3), réseau par réseau.
// events : [{ id, ts, delta, balanceAfter }] ; les SMS arrivés dans le désordre sont remis dans l'ordre (heure puis ID).
// Les trous plus récents que pendingWindowMs sont mis en attente (on n'alerte pas tout de suite) ; un trou n'est signalé qu'une fois.
export function detectGaps(events, { nowMs = Date.now(), pendingWindowMs = 5 * 60 * 1000, alreadyReported = new Set() } = {}) {
  const sorted = [...events].sort((a, b) => a.ts - b.ts || String(a.id).localeCompare(String(b.id)));
  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1], cur = sorted[i];
    const expected = prev.balanceAfter + cur.delta; const diff = cur.balanceAfter - expected;
    if (diff === 0) continue;
    const key = `${prev.id}->${cur.id}`;
    if (alreadyReported.has(key)) continue;
    if (nowMs - cur.ts < pendingWindowMs) { gaps.push({ key, diff, fromTs: prev.ts, toTs: cur.ts, status: "pending" }); continue; }
    gaps.push({ key, diff, fromTs: prev.ts, toTs: cur.ts, status: "alert", hint: diff < 0 ? "float qui baisse : dépôt ou déstockage probable" : "float qui monte : retrait ou approvisionnement probable" });
  }
  return gaps;
}
// Rapprochement : une saisie manuelle et le SMS réel arrivé ensuite (même montant, horaire proche) = une seule opération.
export function matchesManual(manual, sms, windowMs = 30 * 60 * 1000) {
  return manual.nature === sms.nature && manual.amount === sms.amount && Math.abs(manual.ts - sms.ts) <= windowMs;
}
// Seuil de float : une seule notification par franchissement (réarmée quand le niveau est rétabli).
export function thresholdAlert(prevState, balance, threshold) {
  const below = balance <= threshold;
  if (below && !prevState.armedOff) return { notify: true, state: { armedOff: true } };
  if (!below && prevState.armedOff) return { notify: false, state: { armedOff: false } };
  return { notify: false, state: prevState };
}
// Montant à demander au livreur pour revenir à une cible.
export const amountToRequest = (balance, target) => Math.max(0, target - balance);
